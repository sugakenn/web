<?php
	//期限の切れたものをIPテーブルから外します。
	//cronから1分毎に実行することを仮定しています。
	
	//設定ファイル読み込み
	require_once(__DIR__."/setting.php");

	//共通機能読み込み
	require_once(__DIR__."/common.php");
	
	//期限の切れたものをIPテーブルから外す
	getDropData();

	function getDropData() {
		
		$mysql = new classMysql();
		
		if (openMysql($mysql)==false) {
			//DBオープンエラー
			return 1;
		}
		
		//現在の時刻を取得
		$strYmd = date('Y-m-d H:i:s');
		
		//期限切れのユーザを検索するSQL
		$strSqlSel = "SELECT ";
		$strSqlSel .= "mac_address ";
		$strSqlSel .= " FROM userlist ";
		$strSqlSel .= " WHERE ? > limit_time";
		$strSqlSel .= " AND expire_flag=0";
		
		//すでに期限切れにしたユーザはexpire_flagに1をたてて管理対象外にします。
		$strSqlUpd = "UPDATE userlist ";
		$strSqlUpd .= "set expire_flag=1 ";
		$strSqlUpd .= " WHERE mac_address=?";
		
		$psSel = $mysql->getPreparedstatement();
		$psSel->setSql($strSqlSel);
		$psSel->setObject(0,"s",$strYmd);
		
		$psUpd = $mysql->getPreparedstatement();
		$psUpd->setSql($strSqlUpd);
		
		if ($psSel->execute()) {
			while($psSel->next()) {
				//iptablesからのdrop処理
				
				//変更されているかもしれないので、macアドレスからIPアドレスを取得する
				$strIpAddressWk = getIpAddress(getString("mac_address"));
				
				//ipを取得できたら
				if ($strIpAddressWk !== "") { 
					iptalbes($strIpAddressWk, false);
				}
				
				//exprie_flag更新処理
				$psUpd->setObject(0,"s",$psSel->getString("mac_address"));
				$psUpd->execute();
			}
		} else {
			//実行時エラー
			$psSel->close();
			$psUpd->close();
			$mysql->close();
			return 2;
		}
		$psUpd->close();
		$psSel->close();
		$mysql->close();
		
		return 0;
	}
?>