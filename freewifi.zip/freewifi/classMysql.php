<?php

//MySQL(MariaDB)接続管理

class classMysql {
	
	private $mStrErrMsg ="";
	private $mResultsets= array();
	private $mPreparedstatements = array();
	private $mMysqli;
	
	public function open($strServer, $strDb, $strUser, $strPass, $strCharset="utf8") {
		
		if (isset($this->mMysqli)) {
			$this->mMysqli->close();
		}
		
		$this->mMysqli =@new mysqli($strServer,$strUser,$strPass,$strDb);
		
		if (mysqli_connect_errno()) {
			$this->mStrErrMsg = "DB接続に失敗しました";
			return FALSE;	
		}
		
		$this->mMysqli->set_charset($strCharset);
		if (mysqli_connect_errno()) {
			$this->mStrErrMsg = "文字コードセットに失敗しました";
			close();
			return FALSE;
		}
		
		return TRUE;
	}
	
	public function start_transaction(){
		$this->mMysqli->begin_transaction();
	}
	
	public function begin_transaction() {
		$this->mMysqli->begin_transaction();
	}
	
	public function commit() {
		$this->mMysqli->commit();
	}
	
	public function rollback() {
		$this->mMysqli->rollback();
	}
	
	public function execute($strSql) {
		if ($this->mMysqli->real_query($strSql)===FALSE) {
			$this->mStrErrMsg = "SQL実行に失敗しました:".$strSql;
			return FALSE;	
		} else {
			return TRUE;	
		}
	}
	
	public function getResultset() {
		$res = new classResultset($this->mMysqli);
		$this->mResultsets[] = $res;
		return $res;
	}
	
	public function getPreparedStatement() {
		$ps = new classPrepareStatement($this->mMysqli);
		$this->mPreparedstatements[] = $ps;
		return $ps;
	}
	
	public function close() {
		
		if (isset($this->mResultsets)) {
			for ($i = 0; $i < count($this->mResultsets);$i++) {
				$this->mResultsets[$i]->close();
			}
		}
		
		if (isset($this->mPreparedstatements)) {
			for ($i = 0; $i < count($this->mPreparedstatements);$i++) {
				$this->mPreparedstatements[$i]->close();
			}
		}
		
		if (isset($this->mMysqli)) {
			$this->mMysqli->close();
		}
		
	}
	
	public function getErrMsg() {
		return $this->mStrErrMsg;
	}
	
}

class classResultset {
	
	private $mStrErrMsg ="";
	private $mRow=array();
	private $mMysqli = NULL;
	private $mStmt = NULL;
	
	public function __construct(&$mysqli) {
		$this->mMysqli = $mysqli;
	}
	
	public function executeQuery($strSql) {
		
		$this->mStmt = $this->mMysqli->query($strSql);
		
		if ($this->mStmt === FALSE) {
			$this->mStrErrMsg = "SQL実行に失敗しました:".$strSql;
			return FALSE;
		}
	}
	
	public function next($blnAssoc=TRUE) {
		if (isset($this->mStmt) && $this->mStmt !== FALSE) {
			if ($blnAssoc) {
				$this->mRow = $this->mStmt->fetch_assoc();
				if ($this->mRow === NULL) {
					return FALSE;
					
				} else {
					return TRUE;
				}
			} else {
				$this->mRow = $this->mStmt->fetch_row();
				
				if ($this->mRow === NULL) {
					return FALSE;
					
				} else {
					return TRUE;
				}
			}
			
		} else {
			return FALSE;
		}
	}
	
	public function getObject($id,$errorValue="ERROR") {
		if (isset($this->mRow) && isset($this->mRow[$id])) {
			return $this->mRow[$id];
		} else {
			return $errorValue;
		}
	}
	
	public function getString($id,$errorValue="ERROR") {
		if (isset($this->mRow) && isset($this->mRow[$id])) {
			return (string)$this->mRow[$id];
		} else {
			return $errorValue;
		}
	}
	
	public function getInt($id,$errorValue="ERROR") {
		if (isset($this->mRow) && isset($this->mRow[$id])) {
			return (float)$this->mRow[$id];
		} else {
			return $errorValue;
		}
	}
	
	public function getDouble($id,$errorValue="ERROR") {
		if (isset($this->mRow) && isset($this->mRow[$id])) {
			return (float)$this->mRow[$id];
		} else {
			return $errorValue;
		}
	}
	
	
	public function getErrMsg() {
		return $this->mStrErrMsg;
	}
	
	public function close() {
		if (isset($this->mStmt) && $this->mStmt !== FALSE) {
			@$this->mStmt->close();
		}
	}
}

class classPrepareStatement {
	
	private $mStrErrMsg ="";
	private $mRow=array();
	private $mMysqli = NULL;
	private $mStmt = NULL;
	private $mIntPlaceHolderCnt = 0;
	private $mValues = array();
	private $mStrColTypes = array();
	private $mResult =NULL;
	private $mBlnSelect = FALSE;
	
	function __construct(&$mysqli) {
		$this->mMysqli = $mysqli;
	}
	
	public function setSql($strSql) {
		
		$this->mIntPlaceHolderCnt = substr_count($strSql,"?");
		
		if (substr(trim(strtolower($strSql)),0,6)=="select") {
			$this->mBlnSelect = TRUE;
		} else {
			$this->mBlnSelect = FALSE;
		}
		
		//現在の値をクリア
		$this->mStrColTypes = array();
		$this->mValues = array();
		for ($i = 0;$i < $this->mIntPlaceHolderCnt; $i++) {
			$this->mValues[]=NULL;//とりあえずNULLで初期化
			$this->mStrColTypes[]="*";//とりあえず*で初期化
		}
		
		
		$this->mStmt = $this->mMysqli->prepare($strSql);
		
		if ($this->mStmt === FALSE) {
			$this->mStrErrMsg="Prepareに失敗しました:".$strSql;
			return FALSE;
		}
		
		return TRUE;

	}
	
	public function setObject($intIndex,$strType,$value) {
		if ($intIndex < count($this->mValues)) {
			$this->mStrColTypes[$intIndex]=$strType;
			$this->mValues[$intIndex]=$value;
		} else {
			return FALSE;
		}
	}
	
	public function execute() {
		
		$strTypes = "";
		$strValues  ="";
		
		if (isset($this->mStmt)===FALSE || $this->mStmt === NULL || $this->mStmt === FALSE) {
			$this->mStrErrMsg ="ステートメントが用意されていません";
			return FALSE;
		} 
		
		//プレースホルダ
		for ($i = 0; $i < $this->mIntPlaceHolderCnt; $i++) {
			if ($this->mStrColTypes[$i]==="*") {
				$this->mStrErrMsg ="プレースホルダ[".(string)$i."]に値がセットされていません";
				return FALSE;
			}
			
			$strTypes .= $this->mStrColTypes[$i];
			$strValues .=',$this->mValues['.(string)$i.']';
		}
		
		if (0 < $this->mIntPlaceHolderCnt) {
			$strEval = '$this->mStmt->bind_param("'.$strTypes.'"'.$strValues.');';
			if (eval($strEval)===FALSE) {
				$this->mStrErrMsg ="eval error:".$strEval;
				return FALSE;
			}
		}
		
		if ($this->mStmt->execute()===FALSE) {
			$this->mStrErrMsg ="SQL実行エラー";
			return FALSE;
		}
		
		if ($this->mBlnSelect) {
			$this->mResult = $this->mStmt->get_result();
			if ($this->mResult === FALSE) {
				$this->mStrErrMsg ="SQL実行が失敗で終わりました";
				return FALSE;
			}
		} else {
			$this->mResult = FALSE;
		}
		
		return TRUE;
	}
	
	public function next($blnAssoc=TRUE) {
		if (isset($this->mResult) && $this->mResult !== FALSE) {
			if ($blnAssoc) {
				$this->mRow = $this->mResult->fetch_assoc();
				if ($this->mRow === NULL) {
					return FALSE;
					
				} else {
					return TRUE;
				}
			} else {
				$this->mRow = $this->mResult->fetch_row();
				
				if ($this->mRow === NULL) {
					return FALSE;
					
				} else {
					return TRUE;
				}
			}
			
		} else {
			return FALSE;
		}
	}
	
	public function getObject($id,$errorValue="ERROR") {
		if (isset($this->mRow) && isset($this->mRow[$id])) {
			return $this->mRow[$id];
		} else {
			return $errorValue;
		}
	}
	
	public function getString($id,$errorValue="ERROR") {
		if (isset($this->mRow) && isset($this->mRow[$id])) {
			return (string)$this->mRow[$id];
		} else {
			return $errorValue;
		}
	}
	
	public function getInt($id,$errorValue="ERROR") {
		if (isset($this->mRow) && isset($this->mRow[$id])) {
			return (float)$this->mRow[$id];
		} else {
			return $errorValue;
		}
	}
	
	public function getDouble($id,$errorValue="ERROR") {
		if (isset($this->mRow) && isset($this->mRow[$id])) {
			return (float)$this->mRow[$id];
		} else {
			return $errorValue;
		}
	}
	
	public function getErrMsg() {
		return $this->mStrErrMsg;
	}
	
	public function close() {
		if (isset($this->mStmt) && $this->mStmt !== FALSE) {
			@$this->mStmt->close();
		}
	}
}



?>
