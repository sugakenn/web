<?php
	//初期設定をする
	
	//設定ファイル読み込み
	require_once(__DIR__."/setting.php");

	//共通機能読み込み
	require_once(__DIR__."/common.php");
	
	//iptablesの初期化
	resetIptables();
	
	//tc初期化
	resetAndSetTc();
	
	//dbから稼働しているリストを取得
	getInitialData();

	function resetIptables() {
	
		$intRet;
		$strRet;
		
		//iptables リセット
		$strCmd = "sudo /usr/sbin/iptables --flush";
		exec($strCmd,$strRet,$intRet);
		
		//echo $intRet."\n";
		
		//ポリシーを設定
		$strCmd = "sudo /usr/sbin/iptables -P FORWARD DROP";
		exec($strCmd,$strRet,$intRet);
		
		//echo $intRet."\n";
		
		//お客さん側から家の端末へのアクセスを禁止
		$strCmd = "sudo /usr/sbin/iptables -A FORWARD -i ".GC_NIC_CAFE." -s ".GC_CAFE_NETWORK."  -d ".GC_HOME_NETWORK." -j DROP";
		exec($strCmd,$strRet,$intRet);
		
		//echo $intRet."\n";
	}
	
	function resetAndSetTc() {
		$intRet;
		$strRet;
		
		//tc リセット
		$strCmd = makeTcResetCommand(true);
		exec($strCmd,$strRet,$intRet);
		
		//echo $intRet."\n";
		
		$strCmd = makeTcResetCommand(false);
		exec($strCmd,$strRet,$intRet);
		
		//echo $intRet."\n";
		
		//tc セット
		$strCmd = makeTcSetCommand(true);
		exec($strCmd,$strRet,$intRet);
		
		//echo $intRet."\n";
		
		$strCmd = makeTcSetCommand(false);
		exec($strCmd,$strRet,$intRet);
		
		//echo $intRet."\n";
	}
	
	function makeTcResetCommand($blnHome) {
		
		$strAD;
		$strHomeCafe;
		
		if($blnHome) {
			$strHomeCafe= GC_NIC_HOME;
		} else {
			$strHomeCafe= GC_NIC_CAFE;
		}
		
		return "sudo /usr/sbin/tc qdisc del dev ".$strHomeCafe." root";
	}
	
	function makeTcSetCommand($blnHome) {
		
		$strAD;
		$strHomeCafe;
		
		if($blnHome) {
			$strHomeCafe= GC_NIC_HOME;
		} else {
			$strHomeCafe= GC_NIC_CAFE;
		}
		
		return "sudo /usr/sbin/tc qdisc add dev ".$strHomeCafe." root tbf limit ".(string)GC_SPEED."mbit buffer 0.1mbit rate ".(string)GC_SPEED."mbit";
	}
	
	function getInitialData() {
		$mysql = new classMysql();
		
		if (openMysql($mysql)==false) {
			return 1;
		}
		
		$strYmd = date('Y-m-d H:i:s');
		
		$strSql = "SELECT ";
		$strSql .= "ip_address ";
		$strSql .= " FROM userlist ";
		$strSql .= " WHERE ? < limit_time";
		$strSql .= " AND expire_flag=0";
		
		$ps = $mysql->getPreparedstatement();
		$ps->setSql($strSql);
		$ps->setObject(0,"s",$strYmd);
		
		if ($ps->execute()) {
			while($ps->next()) {
				iptalbes($ps->getString("ip_address"), true);
			}
		} else {
			$ps->close();
			$mysql->close();
			return 2;
		}
		
		$ps->close();
		$mysql->close();
		
		return 0;
	}
?>