<?php
	// Free WiFi用設定ファイル
	define("GC_LIMIT_HOUR",1); //1-23までで、1日内での利用可能時間を設定してください
	
	define("GC_NIC_HOME","enp2s0"); //家側のネットワークにつながっているLANアダプタの名称を入力してください。
	define("GC_NIC_CAFE","enp1s0"); //お客さん側のネットワークにつながっているLANアダプタの名称を入力してください。
	
	define("GC_HOME_NETWORK","172.16.101.0/24");//家のネットワークを設定　xxx.xxx.xxx.xxx/24形式(iptablesの初期化で使うセキュリティ設定)
	define("GC_CAFE_NETWORK","192.168.102.0/24");//お客さん側のネットワークを設定　xxx.xxx.xxx.xxx/24形式(iptablesの初期化で使うセキュリティ設定)
	
	define("GC_MANAGE_USER","master"); //Web管理用のユーザー
	define("GC_MANAGE_PASSWORD","stray"); //Web管理用のパスワード
	
	define("GC_MY_PAGE_URL",""); //インターネット上にブログなど持っていたら初期ページに含めますでアドレスを。(https://www.yahoo.co.jp/等)なければ空白に。
	
	define("GC_SQL_SERVER_IP","127.0.0.1"); //MariaDBのあるサーバのIP(127.0.0.1で実行PCを意味しますので通常はそのままで)。
	define("GC_SQL_SERVER_USER","root"); //MariaDBの接続ユーザーを指定してください。
	define("GC_SQL_SERVER_PASS","stray"); //MariaDBの接続パスワードを指定してください。
	
	define("GC_SPEED",20); //速度制限mbps
	
?>