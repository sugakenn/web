<?php
	//通信量を計算し、超過したIPをiptablesの許可設定から外します。
	//cronから1分毎に実行することを仮定しています。
	
	//設定ファイル読み込み
	require_once(__DIR__."/setting2.php");

	//共通機能読み込み
	require_once(__DIR__."/common2.php");
	
	//期限の切れたものをIPテーブルから外す
	getDropData();
	
	function getDropDataSub(&$mysql,$intRetry=3) {
		//通信量を計算してデータベースに格納する。
		
		$strNetWorkAddress = getCafeNetWorkAddressSubnet24();
		
		$aSentDataByIp = array();
		
		//現在の通信量チェック
		$strSqlSel = "SELECT ip_address, sent_data FROM sentdata";
		
		//通信量管理更新用
		$strSqlUpdIp = "INSERT INTO sentdata VALUES(?,?) ON DUPLICATE KEY UPDATE sent_data=?";
		
		//ユーザテーブルの更新用
		$strSqlUpdMac = "INSERT INTO userlist2 VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE sent_data=sent_data+? ";
		
		$psSel = $mysql->getPreparedstatement();
		$psSel->setSql($strSqlSel);
		
		if ($psSel->execute()) {
			while($psSel->next()) {
				$aSentDataByIp[$psSel->getString("ip_address")] = $psSel->getDouble("sent_data");
			}
			$psSel->close();
		} else {
			$psSel->close();
			return false;
		}
		
		$psUpdIp = $mysql->getPreparedstatement();
		$psUpdIp->setSql($strSqlUpdIp);
		
		$psUpdMac = $mysql->getPreparedstatement();
		$psUpdMac->setSql($strSqlUpdMac);
		
		//ユーザー毎の通信量更新
		
		$strCmd = "/usr/sbin/tc -s qdisc show dev ".GC_NIC_CAFE;
		$strResults;
		$intResultCd;
		
		//何かしらの不具合で結果がないといけないので繰り返す
		for ($i = 0; $i < $intRetry; $i++) {
			
			//exec=OSのコマンド($strCmd)を実行して$strResultsに出力メッセージ、$intResultCdに実行結果が返ってくる。
			//ここではサーバが保持するarpテーブルを取得しています。
			exec($strCmd,$strResults,$intResultCd);
			
			//成功していたら
			if ($intResultCd==0) {
				
				//トランザクション開始
				$mysql->start_transaction();
		
				//結果は1行毎に$strResultsに配列で帰ってくるのでその中からWebサーバに接続中の端末のMacアドレス表記を探す。
			 	$strQdiskcs = array();
			 	$k=-1;
			 	for ($j = 0; $j < count($strResults);$j++) {
			 		//一端qdisc単位でデータを格納
			 		
			 		if (0 === strpos($strResults[$j], "qdisc")) {
  						$k++;
  						$strQdiskcs[$k]=$strResults[$j];
					} else {
						$strQdiskcs[$k].=$strResults[$j];
					}
			 	}
			 	
			 	//MACアドレス取得 arpテーブルより
			 	//都度取得していると処理が遅くなるのでここで連想配列に格納
				$aMacAddresses = getMacAddresses();
			 	
			 	//qdiscの中で1001番以降のものを
			 	for ($j = 0; $j < count($strQdiskcs);$j++) {
			 	
			 		//位置を定義
			 		$intQdiscType = 1;
			 		$intQdiscClass = 2; //:が付与されてはいる
			 		$intQdiscSent = 15; //チェック用
			 		$intQdiscByte = 16; //転送量
			 		
			 		$strWk = explode(" ",$strQdiskcs[$j]);
			 		
			 		//indexエラーにならないようにする
			 		if ($intQdiscByte < count($strWk)) {
					 	if($strWk[$intQdiscType]==="sfq" && $strWk[$intQdiscSent]==="Sent") {
					 		//classは1000番台が入っている前提
					 		$intIp4Oct = (int)substr($strWk[$intQdiscClass],1,3);
					 		
					 		if (0 < $intIp4Oct) {
					 			$strIpAddress = $strNetWorkAddress.".".(string)$intIp4Oct;
					 			$intQdiscBytes =  (int)$strWk[$intQdiscByte];
					 			$intAddtionalBytes = 0;
					 			
					 			if (isset($aSentDataByIp[$strIpAddress])) {
					 				//現在と過去を比較
					 				
					 				if ($aSentDataByIp[$strIpAddress] < $intQdiscBytes) {
					 					//大きかったら差分更新、同じか小さい場合は無視
										
					 					$intAddtionalBytes = $intQdiscBytes -$aSentDataByIp[$strIpAddress];
					 					
					 					//IP側を現在値に変更
					 					$psUpdIp->setObject(0,"s",$strIpAddress);
						 				$psUpdIp->setObject(1,"d",$intQdiscBytes);
						 				$psUpdIp->setObject(2,"d",$intQdiscBytes);
						 				
						 				$psUpdIp->execute();
						 				
						 				if (isset($aMacAddresses[$strIpAddress])) {
							 				$psUpdMac->setObject(0,"s",$aMacAddresses[$strIpAddress]);
							 				$psUpdMac->setObject(1,"s",$strIpAddress);
							 				$psUpdMac->setObject(2,"s",date('Y-m-d H:i:s'));
							 				$psUpdMac->setObject(3,"d",$intAddtionalBytes);
							 				$psUpdMac->setObject(4,"d",0);//ins時は0
							 				$psUpdMac->setObject(5,"d",$intAddtionalBytes);
							 				
							 				$psUpdMac->execute();
							 				
							 			}
						 				
					 				} else if ($intQdiscBytes < $aSentDataByIp[$strIpAddress]){
					 					//IP側だけを現在の値に変更
					 					$psUpdIp->setObject(0,"s",$strIpAddress);
						 				$psUpdIp->setObject(1,"d",$intQdiscBytes);
						 				$psUpdIp->setObject(2,"d",$intQdiscBytes);
						 				
						 				$psUpdIp->execute();
					 				}
					 			} else {
					 				
					 				if (0 < $intQdiscBytes) {
					 				
										//IP側を現在値に変更
					 					$psUpdIp->setObject(0,"s",$strIpAddress);
						 				$psUpdIp->setObject(1,"d",$intQdiscBytes);
						 				$psUpdIp->setObject(2,"d",$intQdiscBytes);
						 				
						 				$psUpdIp->execute();
						 				
						 				if (isset($aMacAddresses[$strIpAddress])) {
							 				$psUpdMac->setObject(0,"s",$aMacAddresses[$strIpAddress]);
							 				$psUpdMac->setObject(1,"s",$strIpAddress);
							 				$psUpdMac->setObject(2,"s",date('Y-m-d H:i:s'));
							 				$psUpdMac->setObject(3,"d",$intQdiscBytes);
							 				$psUpdMac->setObject(4,"d",0);//ins時は0
							 				$psUpdMac->setObject(5,"d",$intQdiscBytes);
							 				
							 				$psUpdMac->execute();
						 				}
					 				}
					 			}
					 		}
					 	}
			 		}
			 	}
			 	
			 	//トランザクション終了
			 	$mysql->commit();
			 	
			 	$psUpdIp->close();
			 	$psUpdMac->close();
			 	
			 	return true;//成功
			}
		}
		
		$psUpdIp->close();
		$psUpdMac->close();
		return false;//取得失敗
	
	}

	function getDropData() {
		
		$mysql = new classMysql();
		
		if (openMysql($mysql)==false) {
			//DBオープンエラー
			return 1;
		}
		
		
		//現在の通信量を反映
		getDropDataSub($mysql);
		
		//現在の時刻を取得
		$strYmd = date('Y-m-d H:i:s');
		
		//期限切れのユーザを検索するSQL
		$strSqlSel = "SELECT ";
		$strSqlSel .= "mac_address ";
		$strSqlSel .= " FROM userlist2 ";
		$strSqlSel .= " WHERE sent_data > ".convLimitData();
		$strSqlSel .= " AND expire_flag=0";
		
		//すでに期限切れにしたユーザはexpire_flagに1をたてて管理対象外にします。
		$strSqlUpd = "UPDATE userlist2 ";
		$strSqlUpd .= "set expire_flag=1 ";
		$strSqlUpd .= " WHERE mac_address=?";
		
		$psSel = $mysql->getPreparedstatement();
		$psSel->setSql($strSqlSel);
		
		$psUpd = $mysql->getPreparedstatement();
		$psUpd->setSql($strSqlUpd);
		
		if ($psSel->execute()) {
			while($psSel->next()) {
				//iptablesからのdrop処理
				
				//変更されているかもしれないので、macアドレスからIPアドレスを取得する
				$strIpAddressWk = getIpAddress($psSel->getString("mac_address"));
				
				//ipを取得できたら
				if ($strIpAddressWk !== "") { 
					iptalbes($strIpAddressWk, false);
				}
				
				//exprie_flag更新処理
				$psUpd->setObject(0,"s",$psSel->getString("mac_address"));
				$psUpd->execute();
			}
		} else {
			//実行時エラー
			$psSel->close();
			$psUpd->close();
			$mysql->close();
			return 2;
		}
		$psUpd->close();
		$psSel->close();
		$mysql->close();
		
		return 0;
	}
	
	function getMacAddresses($intRetry = 3) {
		
		//接続中のIPアドレスとMacアドレスのリストを取得する
		
		//特に指定をしない場合は接続中の端末のIPアドレスを使用する
		$strCmd = "ip -4 n";
		$strResults;
		$intResultCd;
		$aRet = array();
		
		//何かしらの不具合で結果がないといけないので繰り返す
		for ($i = 0; $i < $intRetry; $i++) {
		
			//exec=OSのコマンド($strCmd)を実行して$strResultsに出力メッセージ、$intResultCdに実行結果が返ってくる。
			//ここではサーバが保持するarpテーブルを取得しています。
			exec($strCmd,$strResults,$intResultCd);
			
			//成功していたら
			if ($intResultCd==0) {
				//結果は1行毎に$strResultsに配列で帰ってくるのでその中からWebサーバに接続中の端末のMacアドレス表記を探す。
			 	for ($j = 0; $j < count($strResults);$j++) {
			 		//ip -4 nの結果はスペースで区切られているので、スペース毎に分割して$strWk配列に格納
			 		$strWk = explode(" ",$strResults[$j]);
			 		//1番目の配列はIPアドレスなので、それが接続中のIPアドレスとい一致するかチェック(配列は0から始まるので1-1)
			 		
			 		if ($strWk[2] === GC_NIC_CAFE) {
			 			//LANアダプタ毎にあるのでお客さん側だけのみ取得
			 			
			 			$aRet[$strWk[0]] = $strWk[4];
			 		}
			 		
			 	}
			 	
			 	return $aRet;
			}
		}
		
		return $aRet;//取得失敗
	}
	
?>