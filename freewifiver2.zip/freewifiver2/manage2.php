<?php
	//Free Wi-Fi管理ページ
	
	//設定ファイル読み込み
	require_once(__DIR__."/setting2.php");
	
	//共通機能読み込み
	require_once(__DIR__."/common2.php");
	
	//ページに対して簡易的なパスワードをかけています。
	//ユーザー名とパスワードは setting2.phpで設定しています。
	//ネットワークを盗聴されると意味をなさなくなります。
	$blnSuperUser = false;
	if (isset($_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW'])) {
		if ($_SERVER['PHP_AUTH_USER'] === GC_MANAGE_USER) {
			if ($_SERVER['PHP_AUTH_PW'] === GC_MANAGE_PASSWORD) {
				$blnSuperUser = true;
			}
		}
	}
	if ($blnSuperUser === false) {
		header('WWW-Authenticate: Basic realm="Enter username and password."');
		header('Content-Type: text/plain; charset=utf-8');
		die('管理者ログインが必要です');
	}
	//-----------ここまで簡易パスワード処理；
	
	//セッションスタート
	session_start();
	
	$strLastMsg = "";
	
	if (isset($_POST['key'])) {
		if ($_POST['key'] === $_SESSION['key']) {
			if (isset($_POST['mode'])) {
				switch($_POST['mode']) {
				case "extend":
					$strLastMsg = extendUser();
					break;
				case "stop":
					$strLastMsg = stopUser();
					break;
				case "init":
					$strLastMsg = initUser();
					break;
				case "clean":
					$strLastMsg = cleanDb();
					break;
				case "reset":
					$strLastMsg = resetDb();
					break;
				default:
					$strLastMsg = "コマンドが不正です";
				}
			} else {
				$strLastMsg = "コマンドが指定されていません";
			}
		} else {
			$strLastMsg = "実行されませんでした";
		}
	}
	
	//初期ページ読み込み
	$intErrorCd = getCurrentDataAndMakeTable($strLastMsg);
	if ($intErrorCd !== 0) {
		die('エラーが発生しました エラーコード:'.(string)$intErrorCd);
	}
	
	function getCurrentDataAndMakeTable($strLastMsg ="") {
		
		//現在のユーザーリストを表示
		$mysql = new classMysql();
		
		if (openMysql($mysql)==false) {
			return 1;
		}
		
		$strKey = getKey();
		$_SESSION["key"]=$strKey;
		
		$strYmd = date('Y-m-d H:i:s');
		
		$strSqlSel = "SELECT ";
		$strSqlSel .= "mac_address,";
		$strSqlSel .= "ip_address,";
		$strSqlSel .= "start_time,";
		$strSqlSel .= "sent_data,";
		$strSqlSel .= "expire_flag ";
		$strSqlSel .= " FROM userlist2 ";
		$strSqlSel .= " ORDER BY mac_address";
		
		$psSel = $mysql->getPreparedstatement();
		$psSel->setSql($strSqlSel);
		
		if ($psSel->execute()) {
			echo "<!DOCTYPE html>";
			echo "<html>";
			echo "<head>";
			echo '<meta charset="UTF-8">';
			echo '<meta name="viewport" content="width=device-width,initial-scale=1.0">';//画面幅の調整
			echo "<title>Free Wi-Fi管理ページ</title>";
			echo "<style>";//ユーザ一覧テーブルをスクロールできるようにしています。
			echo "table {;";//tableタグに対しての設定
			echo "margin: 0 auto;";//中央揃えの設定ですが、ほとんどはみ出ると思いますので無意味です。
			echo "border-collapse: collapse;";//separateだと隣り合った列の堺に隙間ができます。
			echo "border-spacing:0;";//border-collapseがcollapseの時にセルの間隔を指定します。
			echo "}";
			echo ".scroll-table {";
			echo "overflow: auto;";
			echo "white-space: nowrap;";
			echo "}";
			echo "</style>";
			echo "</head>";
			echo "<body>";
			echo "<p>Free Wi-Fi管理ページ　".$strYmd."時点</p>";
		
			echo '<form name="formmainte" action="#" method="post">';
			
			echo '<div class="scroll-table">';
			echo '<table border="1" style="table-layout: fixed;">';
			echo "<tr>";
			echo "<th>";
			echo "選択";
			echo "</th>";
			echo "<th>";
			echo "macアドレス";
			echo "</th>";
			echo "<th>";
			echo "IPアドレス";
			echo "</th>";
			echo "<th>";
			echo "開始時刻";
			echo "</th>";
			echo "<th>";
			echo "受信量";
			echo "</th>";
			echo "<th>";
			echo "F";
			echo "</th>";
			echo "</tr>";
			
			while($psSel->next()) {
				echo "<tr>";
				echo "<td>";
				echo '<input type="radio" name="macaddress" value="'.$psSel->getString("mac_address").'">';
				echo "</td>";
				echo "<td>";
				echo $psSel->getString("mac_address");
				echo "</td>";
				echo "<td>";
				echo $psSel->getString("ip_address");
				echo "</td>";
				echo "<td>";
				echo $psSel->getString("start_time");
				echo "</td>";
				echo "<td>";
				echo $psSel->getString("sent_data");
				echo "</td>";
				echo "<td>";
				echo (string)$psSel->getInt("expire_flag");
				echo "</td>";
				echo "</tr>";
			}
			echo "</table>";
			echo "</div>";
			
			echo "<p>";
			echo "ユーザ毎の管理<br>";
			echo '<input type="radio" name="mode" value="extend">リセット';
			echo '<input type="radio" name="mode" value="stop">強制停止';
			echo '&nbsp;<button onclick="formmainte.submit();">実行</button>';
			echo "</p>";
			echo "<p>";
			echo "PCの管理<br>";
			echo '<input type="radio" name="mode" value="init">iptables初期化';
			echo '&nbsp;<button onclick="formmainte.submit();">実行</button>';
			echo "</p>";
		
			echo "<p>";
			echo "データベースの管理<br>";
			echo '<input type="radio" name="mode" value="clean">不要アドレス消去';
			echo '<input type="radio" name="mode" value="reset">全データ削除';
			echo '&nbsp;<button onclick="formmainte.submit();">実行</button>';
			echo "</p>";
			echo '<input type="hidden" name="key" value="'.$strKey.'">';
			echo "</form>";
			
			
			echo "<p>";
			echo $strLastMsg."&nbsp;";
			echo "</p>";
			
			echo "</body>";
			echo "</html>";
		} else {
			$psSel->close();
			$mysql->close();
			return 2;
		}
		
		
		$psSel->close();
		$mysql->close();
		
		return 0;
	}
	
	function extendUser() {
		//ユーザーに対して延長設定
		
		$mysql = new classMysql();
		
		$strIpAddress;
		
		if (isset($_POST['macaddress']) == false) {
			return "対象ユーザーが選択されていません";
		}
		
		//DBに設定されている値と実際のIPが変わっている場合があるのでサーバー側で問い合わせる
		$strIpAddress = getIpAddress($_POST['macaddress']);
		
		if ($strIpAddress==="") {
			return "ユーザーのIPアドレス取得に失敗しました";
		}
		
		if (openMysql($mysql)==false) {
			return "DB接続に失敗しました";
		}
		
		
		$strSql = "UPDATE userlist2";
		$strSql .= " SET sent_data=0,";
		$strSql .= "ip_address=?,";
		$strSql .= "expire_flag=0 ";
		$strSql .= " WHERE mac_address=?";
		
		$ps = $mysql->getPreparedstatement();
		$ps->setSql($strSql);
		$ps->setObject(0,"s",$strIpAddress);
		$ps->setObject(1,"s",$_POST['macaddress']);
	
		if ($ps->execute() == false) {
			$ps->close();
			$mysql->close();
			return "DB更新に失敗しました。";
		}
		$ps->close();
		$mysql->close();
		
		//iptables に追加(この関数の実行結果は常に0)
		iptalbes($strIpAddress, true);
		
		return "制限を初期化しました。".$strIpAddress."/".$_POST['macaddress'];
	}
	
	function stopUser() {
		//ユーザーに対して終了設定
		
		$mysql = new classMysql();
		
		$strIpAddress;
		
		if (isset($_POST['macaddress']) == false) {
			return "対象ユーザーが選択されていません";
		}
		
		//DBに設定されている値と実際のIPが変わっている場合があるのでサーバー側で問い合わせる
		$strIpAddress = getIpAddress($_POST['macaddress']);
		
		if ($strIpAddress==="") {
			return "ユーザーのIPアドレス取得に失敗しました";
		}
		
		if (openMysql($mysql)==false) {
			return "DB接続に失敗しました";
		}
		
		
		$strSql = "UPDATE userlist2 ";
		$strSql .= " SET sent_data=?,";
		$strSql .= "ip_address=?,";
		$strSql .= "expire_flag=1 ";
		$strSql .= " WHERE mac_address=?";
		
		echo convLimitData();
		
		$ps = $mysql->getPreparedstatement();
		$ps->setSql($strSql);
		$ps->setObject(0,"d",convLimitData() + 100);
		$ps->setObject(1,"s",$strIpAddress);
		$ps->setObject(2,"s",$_POST['macaddress']);
	
		if ($ps->execute() == false) {
			$ps->close();
			$mysql->close();
			return "DB更新に失敗しました。".$ps->getErrMsg();
		}
		$ps->close();
		$mysql->close();
		
		//iptables に追加(この関数の実行結果は常に0)
		iptalbes($strIpAddress, false);
		
		return "停止しました".$strIpAddress."/".$_POST['macaddress'];
	}
	
	function initUser() {
		//DBの設定でIPテーブルを再設定
		require(__DIR__."/initial2.php");
		return "処理を実行しました";
	}
	
	function resetDb() {
		//ユーザ管理DB削除
		
		$mysql = new classMysql();
		
		if (openMysql($mysql)==false) {
			return "DB接続に失敗しました";
		}
		
		$strSql = "TRUNCATE TABLE userlist2";
		
		$ps = $mysql->getPreparedstatement();
		$ps->setSql($strSql);
		
		if ($ps->execute() == false) {
			$ps->close();
			$mysql->close();
			return "テーブルデータ切り捨てに失敗しました";
		}
		
		$ps->close();
		$mysql->close();
				
		return "テーブルデータを切り捨てました";
	}
	
	function cleanDb() {
		//古いユーザーデータを削除
		
		$mysql = new classMysql();
		
		if (openMysql($mysql)==false) {
			return "DB接続に失敗しました";
		}
		
		$strLimitTime = date('Y-m-d H:i:s', strtotime('-1 day'));
		
		$strSql = "DELETE FROM userlist2 ";
		$strSql .= " WHERE start_time < ?";
		
		$ps = $mysql->getPreparedstatement();
		$ps->setSql($strSql);
		$ps->setObject(0,"s",$strLimitTime);
		
		if ($ps->execute() == false) {
			$ps->close();
			$mysql->close();
			return "古いユーザーデータの削除に失敗しました。";
		}
		$ps->close();
		$mysql->close();
		
		return "古いユーザーデータを削除しました";
	}
	
?>

