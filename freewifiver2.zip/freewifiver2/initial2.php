<?php
	//初期設定をする
	
	//設定ファイル読み込み
	require_once(__DIR__."/setting2.php");

	//共通機能読み込み
	require_once(__DIR__."/common2.php");
	
	//iptablesの初期化
	resetIptables();
	
	//tc初期化
	resetAndSetTc();
	
	//dbから稼働しているリストを取得
	getInitialData();

	function resetIptables() {
	
		$intRet;
		$strRet;
		
		//iptables リセット
		$strCmd = "sudo /usr/sbin/iptables --flush";
		exec($strCmd,$strRet,$intRet);
		
		//echo $intRet."\n";
		
		//ポリシーを設定
		$strCmd = "sudo /usr/sbin/iptables -P FORWARD DROP";
		exec($strCmd,$strRet,$intRet);
		
		//お客さん側から家の端末へのアクセスを禁止
		$strCmd = "sudo /usr/sbin/iptables -A FORWARD -i ".GC_NIC_CAFE." -s ".GC_CAFE_NETWORK."  -d ".GC_HOME_NETWORK." -j DROP";
		exec($strCmd,$strRet,$intRet);
		
		//echo $intRet."\n";
	}
	
	function resetAndSetTc() {
		$intRet;
		$strRet;
		
		//tc リセット
		$strCmd = makeTcResetCommand(true);
		exec($strCmd,$strRet,$intRet);
		
		//echo $intRet."\n";
		
		$strCmd = makeTcResetCommand(false);
		exec($strCmd,$strRet,$intRet);
		
		//echo $intRet."\n";
		
		//tc セット
		setTc();
		
	}
	
	function makeTcResetCommand($blnHome) {
		
		$strAD;
		$strHomeCafe;
		
		if($blnHome) {
			$strHomeCafe= GC_NIC_HOME;
		} else {
			$strHomeCafe= GC_NIC_CAFE;
		}
		
		return "sudo /usr/sbin/tc qdisc del dev ".$strHomeCafe." root";
	}
	
	function setTc() {
		
		$strCmd;
		$strRet;
		$intRet;
		
		//家用のネットワークアダプタはtbfで全体制限＝上り
		$strCmd = "sudo /usr/sbin/tc qdisc add dev ".GC_NIC_HOME." root tbf limit ".(string)GC_SPEED_UPLOAD."mbit buffer 0.1mbit rate ".(string)GC_SPEED_UPLOAD."mbit";
		exec($strCmd,$strRet,$intRet);
		//echo $intRet."\n";
		
		//お客さん用のネットワークアダプタはhtbに
		$strCmd = "sudo /usr/sbin/tc qdisc add dev ".GC_NIC_CAFE." root handle 1: htb default 1000";
		exec($strCmd,$strRet,$intRet);
		//echo $intRet."\n";
		
		//
		$strCmd = "sudo /usr/sbin/tc class add dev ".GC_NIC_CAFE." parent 1: classid 1:100  htb rate ".(string)GC_SPEED."Mbit ceil ".(string)GC_SPEED."Mbit burst 10MB cburst 10MB";
		exec($strCmd,$strRet,$intRet);
		//echo $intRet."\n";
		
		$strNetWork = getCafeNetWorkAddressSubnet24();
		if (GC_CAFE_NETWORK_CLIENTS_START < GC_CAFE_NETWORK_CLIENTS_END &&  0 < GC_CAFE_NETWORK_CLIENTS_START && GC_CAFE_NETWORK_CLIENTS_END < 255) {
			
			//1000番デフォルトのクラス作成
			$i = 0;
			$strCmd = "sudo /usr/sbin/tc class add dev ".GC_NIC_CAFE." parent 1:100 classid 1:".(string)(1000 + $i)." htb rate ".(string)GC_SPEED_USER."Mbit ceil ".(string)GC_SPEED_USER."Mbit burst 10MB cburst 10MB";
			exec($strCmd,$strRet,$intRet);
			//echo "0tc class.".$intRet."\n";
				
			$strCmd = "sudo /usr/sbin/tc qdisc add dev ".GC_NIC_CAFE." parent 1:".(string)(1000+$i)." handle ".(string)(1000+$i).": sfq perturb 10";
			exec($strCmd,$strRet,$intRet);
			//echo "0tc qdisc.".$intRet."\n";
				
			//ループでIP毎の設定を作成
			for ($i = GC_CAFE_NETWORK_CLIENTS_START; $i <= GC_CAFE_NETWORK_CLIENTS_END; $i++) {
				$strCmd = "sudo /usr/sbin/tc class add dev ".GC_NIC_CAFE." parent 1:100 classid 1:".(string)(1000 + $i)." htb rate ".(string)GC_SPEED_USER."Mbit ceil ".(string)GC_SPEED_USER."Mbit burst 10MB cburst 10MB";
				exec($strCmd,$strRet,$intRet);
				//echo (string)$i."tc class.".$intRet."\n";
				
				$strCmd = "sudo /usr/sbin/tc qdisc add dev ".GC_NIC_CAFE." parent 1:".(string)(1000+$i)." handle ".(string)(1000+$i).": sfq perturb 10";
				exec($strCmd,$strRet,$intRet);
				//echo (string)$i."tc qdisc.".$intRet."\n";
				
				$strCmd = "sudo /usr/sbin/tc filter add dev ".GC_NIC_CAFE." protocol ip parent 1:0 prio 1 u32 match ip dst ".$strNetWork.".".(string)$i."/32 flowid 1:".(string)(1000 + $i);
				exec($strCmd,$strRet,$intRet);
				//echo (string)$i."tc filter.".$intRet."\n";
			}
		}
	}
	
	function getInitialData() {
		$mysql = new classMysql();
		
		if (openMysql($mysql)==false) {
			return 1;
		}
		
		//通信量管理テーブルをリセット
		$mysql->execute("truncate table sentdata");
		
		//現在の値でsentdataを更新
		require(__DIR__."/drop2.php");
		
		$strSql = "SELECT ";
		$strSql .= "ip_address ";
		$strSql .= " FROM userlist2 ";
		$strSql .= " WHERE sent_data < ? ";
		$strSql .= " AND expire_flag=0";
		
		$ps = $mysql->getPreparedstatement();
		$ps->setSql($strSql);
		$ps->setObject(0,"d",convLimitData());
		
		if ($ps->execute()) {
			while($ps->next()) {
				iptalbes($ps->getString("ip_address"), true);
			}
		} else {
			$ps->close();
			$mysql->close();
			return 2;
		}
		
		$ps->close();
		
		$mysql->close();
		
		return 0;
	}
?>