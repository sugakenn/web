<?php
	
	//Free Wi-Fi申し込みページ
	
	//設定ファイル読み込み
	require_once(__DIR__."/setting2.php");

	//共通機能読み込み
	require_once(__DIR__."/common2.php");

	//セッション変数を使って不正を防止
	session_start();
	
	if (isset($_POST["key"])) {
		//申し込みを押した場合はこちらにくる。
		
		//不正チェック
		if ($_POST["key"]===$_SESSION["key"]) {
			
			$mysql = new classMysql();
			
			$blnMysql = openMysql($mysql);
			
			$_SESSION["key"] ="";//キーの破棄(リロード等による誤作動を防ぐ)
			
			if ($blnMysql==false) {
				//dbオープンエラー
				echo "<!DOCTYPE html>";
				echo "<html>";
				echo "<head>";
				echo '<meta charset="UTF-8">';
				echo '<meta name="viewport" content="width=device-width,initial-scale=1.0">';
				echo "<title>Free Wi-Fi</title>";
				echo "</head>";
				echo "<body>";
				echo "<p>エラーが発生しました。リロードしてください。</p>";
				echo "</body>";
				echo "<html>";
				exit;
			}
			
			//今日の申し込み状況をチェック（現在時より24時間以内に接続開始されていたら)
			$dbdata = getData2($mysql, $_POST['macaddress']);
			$remain = getRemainData($dbdata['starttime'],$dbdata['sent_data']);
			
			//現在開始されていなかったら開始処理
			if ($remain['alreadystart']) {
				//開始されていた場合で、途中でIPアドレスが変更されていたら、旧アドレスを停止(ただし他の人が使っていなかったら)、別アドレスの登録処理
					
				if ($dbdata['previousip'] !== "" && $dbdata['previousip'] !== $_POST['ipaddress']) {
					
					$blnUseOther = checkOtherIpUser($mysql,$dbdata['previousip'],$_POST['macaddress']);
					
					//エラーとか無視で使われていなかったらiptable drop
					if ($blnUseOther === false) {
						iptalbes($dbdata['previousip'], false);
					}
					
					//現在のIPアドレスをiptablesへ追加
					iptalbes($_POST['ipaddress'], true);
					
					//DBのIPアドレスを更新
					updateIp2($mysql,$_POST['macaddress'],$_POST['ipaddress']);
					
				}
			} else {
				//開始処理
					
				//現在のIPアドレスをiptablesへ追加
				iptalbes($_POST['ipaddress'], true);
				
				//DBのIPアドレスを登録
				insertData2($mysql,$_POST['macaddress'],$_POST['ipaddress'],0);
			}
			
			//dbクローズ
			closeMysql($mysql);
			
			//指定されたエンジンへ移動
			if ($_POST["engine"]==="o") {
				//オリジナルページ
				header('Location: '.GC_MY_PAGE_URL);
				exit;
			} else if($_POST["engine"]==="d") {
				//DDG指定
				header('Location: https://www.duckduckgo.com/');
				exit;
			} else if($_POST["engine"]==="y") {
				//ヤフー指定
				header('Location: https://www.yahoo.co.jp/');
				exit;
			} else {
				//グーグル指定もしくは想定外で、グーグルへ
				header('Location: https://www.google.com/');
				exit;
			}
			
		} else {
			//不正かエラー
			makeWebPage();
		}
	} else {
		//申し込みページへ
		makeWebPage();
	}
	
	function makeWebPage() {
		//webページを作成する
		
		$mysql = new classMysql();

		$blnMysql = openMysql($mysql);
		
		//$strIpAddress = "192.168.102.3"; //デバッグ用
		$strIpAddress = $_SERVER["REMOTE_ADDR"];//接続中の端末のアドレスは$_SERVER["REMOTE_ADDR"]に格納されている。
		$strMacAddress = getMacAddress($strIpAddress);
		$strKey = getKey();
		
		$dbdata = getData2($mysql,$strMacAddress);
		$remain = getRemainData($dbdata['starttime'],$dbdata['sent_data']);
		$_SESSION["key"]=$strKey;
		
		closeMysql($mysql);
		
		echo "<!DOCTYPE html>";
		echo "<html>";
		echo "<head>";
		echo '<meta charset="UTF-8">';
		echo '<meta name="viewport" content="width=device-width,initial-scale=1.0">';//画面幅の調整
		echo "<title>Free Wi-Fi</title>";
		echo "</head>";
		echo "<body>";
		echo "<p>Free Wi-Fiスタートページ</p>";
		echo "<p>1日あたり約 ".(string)GC_LIMIT_DATA."GByteお使いいただけます。(通信量)</p>";
		echo '<form action="#" method="post">';
		echo '<input name="key" type="hidden" value="'.$strKey.'">';
		echo '<input name="ipaddress" type="hidden" value="'.$strIpAddress.'">';
		echo '<input name="macaddress" type="hidden" value="'.$strMacAddress.'">';
		echo '<p>初期ページ<br>';
		if (GC_MY_PAGE_URL!=="") {
			echo '<input type="radio" name="engine" value="o" checked>当店ページ<br>';
			echo '<input type="radio" name="engine" value="g">Google<br>';
		} else {
			echo '<input type="radio" name="engine" value="g" checked>Google<br>';
		}
		echo '<input type="radio" name="engine" value="y">YAHOO!<br>';
		echo '<input type="radio" name="engine" value="d">DuckDuckGo<br>';
		echo '</p>';
		if ($blnMysql == false || $dbdata['error']) {
			echo "<p>エラーが発生している為現在ご利用できません</p>";
		} else {
			if ($remain['alreadystart']) {
				if ($remain['remaindata'] <=0) {
					echo "<p>ご利用制限に達しました(".$strMacAddress.")</p>";
					echo '<button type="submit" disabled>ご利用できません</button>';
					$_POST["key"]="";//POSTされても無効にする
				} else {
					echo "<p>通信量残:".(string)$remain['remaindata']."%</p>";
					echo '<button type="submit">継続ご利用</button>';
				}
			} else {
				echo "<p>ご利用可能です</p>";
				echo '<button type="submit">ご利用開始</button>';
			}
		}
		echo "</body>";
		echo "</html>";
		echo "</form>";
	}
	
?>
