<?php
	// Free WiFi用設定ファイル(通信量制限版・サブネットマスクが255.255.255.0より範囲が広い場合はプログラム全体を変更してください)
	
	define("GC_LIMIT_DATA",1); //制限データ量を設定。単位Gバイト。小数可能。
	
	define("GC_NIC_HOME","enp2s0"); //家側のネットワークにつながっているLANアダプタの名称を入力してください。
	define("GC_NIC_CAFE","enp1s0"); //お客さん側のネットワークにつながっているLANアダプタの名称を入力してください。
	
	define("GC_HOME_NETWORK","172.16.101.0/24");//家のネットワークを設定　xxx.xxx.xxx.xxx/24形式(iptablesの初期化で使うセキュリティ設定)
	define("GC_CAFE_NETWORK","192.168.102.0/24");//お客さん側のネットワークを設定　xxx.xxx.xxx.xxx/24形式(iptablesの初期化で使うセキュリティ設定)
	
	define("GC_CAFE_NETWORK_CLIENTS_START",1);//お客さん側のネットワークIPアドレス割り振り開始
	define("GC_CAFE_NETWORK_CLIENTS_END",128);//お客さん側のネットワークIPアドレス割り振り終了
	//DHCPが割り当てるIPアドレスを網羅するように設定してください。
	//間に割り当てられないIPがあっても問題ありません。
		
	define("GC_MANAGE_USER","master"); //Web管理用のユーザー
	define("GC_MANAGE_PASSWORD","stray"); //Web管理用のパスワード
	
	define("GC_MY_PAGE_URL",""); //インターネット上にブログなど持っていたら初期ページに含めますでアドレスを。(https://www.yahoo.co.jp/等)なければ空白に。
	
	define("GC_SQL_SERVER_IP","127.0.0.1"); //MariaDBのあるサーバのIP(127.0.0.1で実行PCを意味しますので通常はそのままで)。
	define("GC_SQL_SERVER_USER","root"); //MariaDBの接続ユーザーを指定してください。
	define("GC_SQL_SERVER_PASS","stray"); //MariaDBの接続パスワードを指定してください。
	
	define("GC_SPEED",20); //下り速度制限(全体)mbps
	define("GC_SPEED_USER",5); //下り速度制限(個人)mbps
	define("GC_SPEED_UPLOAD",2);//上り速度制限mbps アップロードは通信量の中には含まず、全体での制限とします。
?>