<?php
	
	//複数のページから使いそうな機能をまとめてあります。
	
	//データベース操作クラス追加
	require_once(__DIR__."/classMysql.php");
	
	// 各種共通機能
	function getKey() {
		//不正防止のための簡易キー作成
	
		$strRet="";
		for ($i =0; $i < 10; $i++) {
			$strRet.=rand(0,9);
		}
		return $strRet;
	}
	
	function iptalbes($strIp, $blnOnOff) {
		
		exec(makeIptablesCommand($strIp,$blnOnOff,true));
		exec(makeIptablesCommand($strIp,$blnOnOff,false));
		
		return 0;
	}
	
	function makeIptablesCommand($strIp, $blnOn, $blnHome) {
		
		$strAD;
		$strHomeCafe;
		
		if($blnOn) {
			$strAD= "A";
		} else {
			$strAD = "D";
		}
		
		if($blnHome) {
			$strHomeCafe= GC_NIC_HOME." -d";
		} else {
			$strHomeCafe= GC_NIC_CAFE." -s";
		}
		
		return "sudo /usr/sbin/iptables -".$strAD." FORWARD -i ".$strHomeCafe." ".$strIp." -j ACCEPT";
	}
	
	function getMacAddress($strIpAddress,$intRetry=3) {
		
		//接続中のIPアドレスからMacアドレスを取得する
		
		//特に指定をしない場合は接続中の端末のIPアドレスを使用する
		$strCmd = "ip -4 n";
		$strResults;
		$intResultCd;
		
		
		//何かしらの不具合で結果がないといけないので繰り返す
		for ($i = 0; $i < $intRetry; $i++) {
		
			//exec=OSのコマンド($strCmd)を実行して$strResultsに出力メッセージ、$intResultCdに実行結果が返ってくる。
			//ここではサーバが保持するarpテーブルを取得しています。
			exec($strCmd,$strResults,$intResultCd);
			
			//成功していたら
			if ($intResultCd==0) {
				//結果は1行毎に$strResultsに配列で帰ってくるのでその中からWebサーバに接続中の端末のMacアドレス表記を探す。
			 	for ($j = 0; $j < count($strResults);$j++) {
			 		//ip -4 nの結果はスペースで区切られているので、スペース毎に分割して$strWk配列に格納
			 		$strWk = explode(" ",$strResults[$j]);
			 		//1番目の配列はIPアドレスなので、それが接続中のIPアドレスとい一致するかチェック(配列は0から始まるので1-1)
			 		if ($strWk[0]===$strIpAddress) {
			 			//一致したら5番目がMACアドレスなので、それを返す。(配列は0から始まるので5-1)
			 			return $strWk[4];
			 		}
			 	}
			}
		}
		
		return "";//取得失敗
	}
	
	function getIpAddress($strMacAddress,$intRetry=3) {
		
		//接続中のMacアドレスからIpアドレスを取得する
		
		//特に指定をしない場合は接続中の端末のIPアドレスを使用する
		$strCmd = "ip -4 n";
		$strResults;
		$intResultCd;
		
		
		//何かしらの不具合で結果がないといけないので繰り返す
		for ($i = 0; $i < $intRetry; $i++) {
			//exec=OSのコマンド($strCmd)を実行して$strResultsに出力メッセージ、$intResultCdに実行結果が返ってくる。
			//ここではサーバが保持するarpテーブルを取得しています。
			exec($strCmd,$strResults,$intResultCd);
			
			//成功していたら
			if ($intResultCd==0) {
				//結果は1行毎に$strResultsに配列で帰ってくるのでその中からWebサーバに接続中の端末のMacアドレス表記を探す。
			 	for ($j = 0; $j < count($strResults);$j++) {
			 		//ip -4 nの結果はスペースで区切られているので、スペース毎に分割して$strWk配列に格納
			 		$strWk = explode(" ",$strResults[$j]);
			 		//5番目の配列はMacアドレスなので、それが接続中のMacアドレスとい一致するかチェック(配列は0から始まるので5-1)
			 		if ($strWk[4]===$strMacAddress) {
			 			//一致したら1番目がIPアドレスなので、それを返す。(配列は0から始まるので1-1)
			 			return $strWk[0];
			 		}
			 	}
			}
		}
		
		return "";//取得失敗
	}
	
	function openMysql(&$mysql) {
		//DB接続
		if ($mysql->open(GC_SQL_SERVER_IP,"freewifi",GC_SQL_SERVER_USER,GC_SQL_SERVER_PASS)==false) {
			return false;
		}
		
		return true;
	}
	
	function closeMysql(&$mysql) {
		$mysql->close();
	}
	
	function getData2(&$mysql, $strMacAddress) {
			
		//mac アドレス毎に現在の状況を確認
		$aRet = array();
		
		$aRet['macaddress']=$strMacAddress;
		$aRet['previousip']="";//前回のIP変更されている可能性がある
		$aRet['starttime']=0;//開始時間
		$aRet['sent_data']=0;//通信量
		$aRet['error']=true;
		$aRet['new']=false;
		$aRet['errormsg']="";
		
		$strSql = "SELECT ";
		$strSql .= "ip_address,";
		$strSql .= "start_time,";
		$strSql .= "sent_data";
		$strSql .= " FROM userlist2 ";
		$strSql .= " WHERE mac_address=?";
		
		$ps = $mysql->getPreparedstatement();
		$ps->setSql($strSql);
		$ps->setObject(0,"s",$strMacAddress);
		
		if ($ps->execute()) {
			if($ps->next()) {
				$aRet['previousip'] = $ps->getString("ip_address");
				$aRet['starttime'] = getUtc($ps->getString("start_time"));
				$aRet['sent_data'] = $ps->getDouble("sent_data");
				$aRet['error']=false;
			} else {
				$aRet['error']=false;
				$aRet['new']=true;
			}
		} else {
			$aRet['errormsg']="実行時にエラーが発生しました";
		}
		
		$ps->close();

		
		return $aRet;
	}
	
	function checkOtherIpUser(&$mysql, $strIpAddress, $strMacAddress) {
			
		//IPアドレスが他で使われていないかチェック
		$blnResult = false;
		
		$strSql = "SELECT ";
		$strSql .= "ip_address,";
		$strSql .= "start_time,";
		$strSql .= "limit_time";
		$strSql .= " FROM userlist2 ";
		$strSql .= " WHERE mac_address <> ?";
		$strSql .= " AND ip_address = ?";
		$strSql .= " AND start_time < limit_time";
		
		$ps = $mysql->getPreparedstatement();
		$ps->setSql($strSql);
		$ps->setObject(0,"s",$strMacAddress);
		$ps->setObject(1,"s",$strIpAddress);
		
		if ($ps->execute()) {
			if($ps->next()) {
				$blnResult = true;
			} else {
				$blnResult = false;
			}
		} else {
			//実行エラー
			$blnResult = null;
		}
		
		$ps->close();
		
		return $blnResult;
	}
	
	function updateIp2(&$mysql, $strMacAddress, $strIpAddress) {
			
		//IPアドレスだけ変更
		$blnResult = false;
		
		$strSql = "UPDATE userlist2";
		$strSql .= " SET ip_address=? ";
		$strSql .= " WHERE mac_address=?";
		
		$ps = $mysql->getPreparedstatement();
		$ps->setSql($strSql);
		$ps->setObject(0,"s",$strIpAddress);
		$ps->setObject(1,"s",$strMacAddress);
		
		if ($ps->execute()) {
			$blnResult = true;
		} else {
			$blnResult = false;
		}
		
		$ps->close();
		
		return $blnResult;
	}
	
	function updateExpire(&$mysql, $intExpire) {
			
		//expire_flagだけ変更
		$blnResult = false;
		
		$strSql = "UPDATE userlist2";
		$strSql .= "SET expire_flag=? ";
		$strSql .= " WHERE mac_address = ?";
			
		$ps = $mysql->getPreparedstatement();
		$ps->setSql($strSql);
		$ps->setObject(0,"s",$intExpire);
		$ps->setObject(1,"s",$strMacAddress);
		
		if ($ps->execute()) {
			$blnResult = true;
		} else {
			$blnResult = false;
		}
		
		$ps->close();
		
		return $blnResult;
	}
	
	function insertData2(&$mysql, $strMacAddress, $strIpAddress, $dblSentData) {
			
		//IPアドレスだけ変更
		$blnResult = false;
		
		$strSql = "REPLACE INTO userlist2 VALUES(?,?,?,?,?)";
			
		$ps = $mysql->getPreparedstatement();
		$ps->setSql($strSql);
		$ps->setObject(0,"s",$strMacAddress);
		$ps->setObject(1,"s",$strIpAddress);
		$ps->setObject(2,"s",date('Y-m-d H:i:s'));
		$ps->setObject(3,"d",$dblSentData);
		$ps->setObject(4,"s",0);
		
		
		if ($ps->execute()) {
			$blnResult = true;
		} else {
			$blnResult = false;
		}
		
		$ps->close();
		
		return $blnResult;
	}
	
	
	function convLimitData() {
		if (GC_LIMIT_DATA <=0) {
			return 1 * 1024 * 1024 * 1024;
		} else {
			return floor(GC_LIMIT_DATA * 1024 * 1024 * 1024);
		}
	}
	
	function getRemainData($starttime,$sentdata) {
		
		//$starttimeは秒で入っている前提
		
		$intRemain = 
		
		$aRet = array();
		
		//現在の時刻を秒で取得
		$lngNow = getUtc();
		
		//前回開始した後24時間後を秒で取得
		$lngWk = $starttime + (24 * 60 * 60);
		
		//もし前回開始日から24時間以上経過していたら
		if($lngWk < $lngNow) {
		
			$aRet['alreadystart']=false;
			$aRet['remaindata']=100;
			
			return $aRet;
		} else {
			$aRet['alreadystart']=true;
			$intPercentWk = convLimitData() - $sentdata;
			
			if ($intPercentWk <= 0) {
				$aRet['remaindata'] =0;
			} else {
				$aRet['remaindata'] =floor($intPercentWk * 100 / convLimitData());
			}
			
			return $aRet;
		}
	}
	
	function getCafeNetWorkAddressSubnet24() {
		//サブネットマスク24決め打ちで、カフェ側のネットワークアドレスを取得
		//GC_CAFE_NETWORKに正しく値が入っている前提
		$b = false;
		$strRet = "";
		
		for ($i = strlen(GC_CAFE_NETWORK)-2; 0 <= $i; $i--) {
			if ($b) {
				$strRet = substr(GC_CAFE_NETWORK,$i,1).$strRet;
			} else {
				if (substr(GC_CAFE_NETWORK,$i,1) === ".") {
					$b = true;
				} 
			}
		}
		return $strRet;
	}
	
	function getUtc($strYmdHis = ""){
		//UTC秒を取得
		if ($strYmdHis === "") {
			$strYmdHis = date('Y-m-d H:i:s');
		}
		return strtotime($strYmdHis.' UTC');
	}
?>