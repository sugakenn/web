<?php

/**
 * DHCPリレー管理.PHP 
 *
 * The MIT License
 *
 * Copyright (c) 2020 なんぶ電子
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
 
 /* 使い方や環境設定については
  * https://seedoftalk.blogspot.com/2020/05/dhcpd-and-relay-agent.html
  * に掲載しています。
  */
  
//　設定
define('C_MANAGE_USER','cat');//管理ユーザー名を入力
define('C_MANAGE_PASSWORD','222');//管理パスワードを入力
define('C_USER_LIST','userlist');//MACアドレス ユーザー名を管理するファイル
define('C_NETWORK_LIST','networklist');//ネットワークアドレス サブネット リース範囲を管理するファイル
define('C_LOG_PATH','/var/log/dhcp.log');//dhcpログの場所
define('C_LOG_MAX_PAGES',14);//dhcp過去ログの上限

function getLogPath() {
	if (isSet($_POST['page'])) {
		//ページ指定あり
		if ($_POST['page']==="0") {
			return C_LOG_PATH;
		} else {
			//過去のログは同じ場所に.1という風に接尾番号がつく前提です。
			//そうでない場合は環境に合わせて修正してください。
			return C_LOG_PATH.".".$_POST['page'];
		}
	} else {
		return C_LOG_PATH;
	}
}

function getConfEntries() {
	//dhcpd.conf作成時のグローバルエントリーです。環境に合わせて設定してください。
	//配列に入れたテキストをそのまま出力しますので;が必要な個所には入れてください。
	
	$entries = array();
	
	$entries[]="option domain-name-servers 8.8.8.8;";
	$entries[]="default-lease-time 600;";
	$entries[]="max-lease-time 7200;";
	$entries[]="ddns-update-style none;";
	$entries[]="authoritative;";
	$entries[]="log-facility local7;";
	$entries[]="deny unknown-clients;";
	
	/*
	 * DHCPサーバーが所属するネットワークに対してDHCPでの動的割り当てをしたくない場合は、
	 * 設定ファイル上にDHCPサーバーがあるネットワークのエントリーがないとエラーになりますので、
	 * ここで空のネットワークエントリーを入れてください。
	 */
	 
	//$entries[]="subnet 192.168.1.0 netmask 255.255.255.0{}";
	
	
	return $entries;

}

//設定ページに対して簡易的なパスワードをかけています。
//ネットワーク内の通信を監視するとユーザー名とパスワードが見らてしまいます。
$blnSuperUser = false;
if (isset($_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW'])) {
	if ($_SERVER['PHP_AUTH_USER'] === C_MANAGE_USER) {
		if ($_SERVER['PHP_AUTH_PW'] === C_MANAGE_PASSWORD) {
			$blnSuperUser = true;
		}
	}
}

if ($blnSuperUser === false) {
	header('WWW-Authenticate: Basic realm="Enter username and password."');
	header('Content-Type: text/plain; charset=utf-8');
	die('管理者ログインが必要です');
}

$strMsg="";

if (isset($_POST['users'])) {
	//もしユーザー設定変更が送信されてきたら書き込み
	$params = explode("\t",$_POST['users']);
	$fp = fopen(C_USER_LIST, 'w');
	$intLoopStep=2;
	if ($fp) {
		flock($fp, LOCK_EX);
		for ($i = 0; $i < count($params); $i=$i+$intLoopStep) {
			for($j = 0; $j < $intLoopStep; $j++) {
				if ($j !==0) {
					fputs($fp,"\t");
				}
				fputs($fp,$params[$i+$j]);
			}
			fputs($fp,"\r\n");
		}
		
		
		$strMsg="書き込みました";
	} else {
		$strMsg="書き込みに失敗しました";
	}
	fclose($fp);
	
	echo '<html><head></head><bod>'.$strMsg.'</body><html>';
	exit;
}
if (isset($_POST['networks'])) {
	//もしネットワーク設定変更が送信されてきたら書き込み
	$params = explode("\t",$_POST['networks']);
	$fp = fopen(C_NETWORK_LIST, 'w');
	$intLoopStep=5;
	if ($fp) {
		flock($fp, LOCK_EX);
		for ($i = 0; $i < count($params); $i=$i+$intLoopStep) {
			for($j = 0; $j < $intLoopStep; $j++) {
				if ($j !==0) {
					fputs($fp,"\t");
				}
				fputs($fp,$params[$i+$j]);
			}
			fputs($fp,"\r\n");
		}
		
		
		$strMsg="書き込みました";
	} else {
		$strMsg="書き込みに失敗しました";
	}
	fclose($fp);
	
	echo '<html><head></head><bod>'.$strMsg.'</body><html>';
	exit;
}
if (isset($_POST['conf'])) {
	//もし設定ファイル書き込み要求が送信されてきたら書き込み
	$fpw = false;
	$fpn = false;
	$fpu = false;
	$blnErr = false;
	$strErr = "";
	
	if (!$blnErr) {
		$fpn = fopen(C_NETWORK_LIST, 'r');
		if ($fpn === false) {
			$strMsg="ネットワーク設定ファイルオープンに失敗しました";
			$blnErr =true;
		}
	}
	if (!$blnErr) {
		$fpu = fopen(C_USER_LIST, 'r');
		if ($fpu === false) {
			$strMsg="ユーザー設定ファイルオープンに失敗しました";
			$blnErr =true;
		}
	}

	if (!$blnErr) {
		$fpw = fopen("./dhcpd.conf.txt", 'w');
		
		if ($fpw) {
			flock($fpw, LOCK_EX);
			
			//グローバルエントリー書き込み
			$aEntries = getConfEntries();
			
			fputs($fpw,"# Sample configuration file for ISC dhcpd"."\n");
			
			for ($i = 0; $i < count($aEntries); $i++) {
				fputs($fpw,$aEntries[$i]."\n");
			}
			
			//ユーザー設定書き込み
			$intHostIndex = 0;
			while ($strLine = rtrim(fgets($fpu))) {
		 		if (substr(trim($strLine),0,1)!=="#") {
		 			$aWk = explode("\t",$strLine);
		 			$intHostIndex++;
					fputs($fpw,"host host".(string)$intHostIndex." { hardware ethernet ".$aWk[0]."; }\n");
				}
			}
			
			//ネットワーク設定書き込み
			while ($strLine = rtrim(fgets($fpn))) {
		 		if (substr(trim($strLine),0,1)!=="#") {
		 			
		 			$aWk = explode("\t",$strLine);
		 			$strWk = convNetworkAddress($aWk[0]);
		 			if ($strWk !== null && 4 < count($aWk)) {
						fputs($fpw,"subnet ".$strWk." {\n");
						fputs($fpw,"  range ".$aWk[3]." ".$aWk[4]."; \n");
						fputs($fpw,"  option routers ".$aWk[2]."; \n");
						fputs($fpw,"}\n");
					} else {
						$strErr .= "!network設定エラー:".$strLine;
					}
				}
			}
			
			$strMsg="設定ファイルをサーバーのdhcpd.conf.txtファイルへ出力しました。".$strErr;
		} else {
			$strMsg="出力ファイルオープンに失敗しました";
		}
	}
	
	if ($fpw !== false) {
		fclose($fpw);
	}
	if ($fpu !== false) {
		fclose($fpu);
	}
	if ($fpn !== false) {
		fclose($fpn);
	}
	echo '<html><head></head><bod>'.$strMsg.'</body><html>';
	exit;
}


?>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0">
<title>DHCPリース情報</title>
<!-- ブラウザ上でデータを編集するためのJavaスクリプト -->
<script>
let mRequest;
let mIntMsgTarget = 0;
window.onload = function() {
 //post用
 mRequest = new XMLHttpRequest();
 
 mRequest.onload = function (e) {
  if (mRequest.readyState === 4) {
   if (mRequest.status === 200) {
    switch(mIntMsgTarget) {
    case 1:
	 document.getElementById('spanstatus1').innerHTML=mRequest.responseText;
	 break;
	case 2:
     document.getElementById('spanstatus2').innerHTML=mRequest.responseText;
     break;
    default:
     document.getElementById('spanstatus1').innerHTML=mRequest.responseText;
	 document.getElementById('spanstatus2').innerHTML=mRequest.responseText;
    }
   }
  }
 };
};

function delUser() {
 //ユーザー設定行の削除
 let strMac = document.getElementById('txtmac').value.toLowerCase();
 
 if (strMac === "") {
  document.getElementById('spanstatus1').innerHTML="MACを空白にはできません";
  return;
 }
 let i = 0;
 let oTable = document.getElementById('tbluser');
 for (let oRow of oTable.rows) {
   if (oRow.cells[0].innerText===strMac) {
    oRow.remove();
    document.getElementById('txtmac').value="";
    document.getElementById('spanstatus1').innerHTML="";
    return;
   }
 }
 document.getElementById('spanstatus1').innerHTML="MACが存在しませんでした";
}

function delNetwork() {
 //ネットワーク設定行の削除
 let strNetwork = document.getElementById('txtnetwork').value.toLowerCase();
 
 if (strNetwork === "") {
  document.getElementById('spanstatus1').innerHTML="Networkを空白にはできません";
  return;
 }
 let i = 0;
 let oTable = document.getElementById('tblnetwork');
 for (let oRow of oTable.rows) {
   if (oRow.cells[0].innerText===strNetwork) {
    oRow.remove();
    document.getElementById('txtNetwork').value="";
    document.getElementById('spanstatus2').innerHTML="";
    return;
   }
 }
 document.getElementById('spanstatus2').innerHTML="Netwrokが存在しませんでした";
}

function addUser() {
 //ユーザー設定、登録変更
 let strMac = document.getElementById('txtmac').value.toLowerCase();
 let strName = document.getElementById('txtname').value.replace(/\t/g,'');
 
 if (strMac.match(/[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}/g) === null) {
  document.getElementById('spanstatus1').innerHTML="MACアドレスが不正です";
  return;
 }
 if (strName === "") {
  document.getElementById('spanstatus1').innerHTML="名前を空白にはできません";
  return;
 }
 let i = 0;
 let oTable = document.getElementById('tbluser');
 for (let oRow of oTable.rows) {
   if (oRow.cells[0].innerText===strMac) {
    oRow.cells[1].innerText=strName;
    document.getElementById('txtmac').value="";
    document.getElementById('txtname').value="";
    return;
   }
 }
 let oIRow = oTable.insertRow();
 oIRow.insertCell().appendChild(document.createTextNode(strMac));
 oIRow.insertCell().appendChild(document.createTextNode(strName));
 
 document.getElementById('txtmac').value="";
 document.getElementById('txtname').value="";
 
 document.getElementById('spanstatus1').innerHTML="";
}

function addNetwork() {
 //ネットワーク設定、登録変更
 let strNetwork = document.getElementById('txtnetwork').value.toLowerCase();
 let strName = document.getElementById('txtnname').value.replace(/\t/g,'');
 let strGateway = document.getElementById('txtgateway').value;
 let strFrom = document.getElementById('txtfrom').value;
 let strTo = document.getElementById('txtto').value;
 let aNetwork = strNetwork.match(/^([0-9]{1,3}).([0-9]{1,3}).([0-9]{1,3}).([0-9]{1,3})\/([0-9]{1,2})$/);
 let aGateway = strGateway.match(/^([0-9]{1,3}).([0-9]{1,3}).([0-9]{1,3}).([0-9]{1,3})$/);
 let aFrom = strFrom.match(/^([0-9]{1,3}).([0-9]{1,3}).([0-9]{1,3}).([0-9]{1,3})$/);
 let aTo = strTo.match(/^([0-9]{1,3}).([0-9]{1,3}).([0-9]{1,3}).([0-9]{1,3})$/); 
 let aIntNetwork=[0,0,0,0,0];
 let lngFrom=0;
 let lngTo=0;

 let aIntNetMask=[255,255,255,255];
 
 //入力データチェック
 if (aNetwork === null) {
  document.getElementById('spanstatus2').innerHTML="Network/Maskが不正です";
  return;
 }
 if (aGateway === null) {
  document.getElementById('spanstatus2').innerHTML="ルーター(デフォルトゲートウェイ）のIPアドレスが不正です";
  return;
 }
 if (aFrom === null) {
  document.getElementById('spanstatus2').innerHTML="リース範囲開始のIPアドレスが不正です";
  return;
 }
 if (aTo === null) {
  document.getElementById('spanstatus2').innerHTML="リース範囲終了のIPアドレスが不正です";
  return;
 }
 
 for (let i=1; i < aNetwork.length; i++) {
  aIntNetwork[i-1]=parseInt(aNetwork[i],10);
  if (255 < aIntNetwork[i-1]) {
   document.getElementById('spanstatus2').innerHTML="Networkに設定された値が不正です";
   return;
  }
 }
 
 //プライベートアドレスになるように制限
 switch(aIntNetwork[0]) {
 case 192:
  if (aIntNetwork[1] !== 168) {
   document.getElementById('spanstatus2').innerHTML="Networkにはプライベートアドレスを設定してください";
   return;
  }
  if (aIntNetwork[4] < 16 || 31 < aIntNetwork[4]) {
   document.getElementById('spanstatus2').innerHTML="Maskの値が不正です";
   return;
  }
  break;
 case 172:
  if (aIntNetwork[1] < 16 || 31 < aIntNetwork[1]) {
   document.getElementById('spanstatus2').innerHTML="Networkにはプライベートアドレスを設定してください";
   return;
  }
  if (aIntNetwork[4] < 12 || 31 < aIntNetwork[4]) {
   document.getElementById('spanstatus2').innerHTML="Maskの値が不正です";
   return;
  }
  break;
 case 10:
  if (aIntNetwork[4] < 8 || 31 < aIntNetwork[4]) {
   document.getElementById('spanstatus2').innerHTML="Maskの値が不正です";
   return;
  }
  break;
 default:
  document.getElementById('spanstatus2').innerHTML="Networkにはプライベートアドレスを設定してください";
  return;
 }
 
 //ネットマスクを変換
 if (aIntNetwork[4] < 16) {
  aIntNetMask[1]=parseInt('1'.repeat(aIntNetwork[4]-8)+'0'.repeat(8-(aIntNetwork[4]-8)),2);
  aIntNetMask[2]=0;
  aIntNetMask[3]=0;
 } else if(aIntNetwork[4] < 24) {
  aIntNetMask[2]=parseInt('1'.repeat(aIntNetwork[4]-16)+'0'.repeat(8-(aIntNetwork[4]-16)),2);
  aIntNetMask[3]=0;
 } else {
  aIntNetMask[3]=parseInt('1'.repeat(aIntNetwork[4]-24)+'0'.repeat(8-(aIntNetwork[4]-24)),2);
 }
 
 //ネットマスクでネットワーク情報を更新
 for(let i = 0; i < 4; i++) {
  aIntNetwork[i] = aIntNetwork[i] & aIntNetMask[i];
 }
 
 //ゲートウェイが範囲にいるかチェック
 //aGateWayには[0]matchの最大一致,1からIPの1オクテット目が入る。
 for (let i=0; i < 4; i++) {
  if ((parseInt(aGateway[i+1],10) & aIntNetMask[i]) !== aIntNetwork[i]) {
   document.getElementById('spanstatus2').innerHTML="ルーターのアドレスがネットワークに所属していません";
   return;
  }
 }
 
 //リース開始アドレスがネットワーク内にいるかチェック
 //aFromには[0]matchの最大一致,1からIPの1オクテット目が入る。
 for (let i=0; i < 4; i++) {
  if ((parseInt(aFrom[i+1],10) & aIntNetMask[i]) !== aIntNetwork[i]) {
   document.getElementById('spanstatus2').innerHTML="リース範囲開始のアドレスがネットワークに所属していません";
   return;
  }
  lngFrom += parseInt(aFrom[i+1],10) * Math.pow(256,4-i);
 }
 
 //リース終了アドレスがネットワーク内にいるかチェック
 for (let i=0; i < 4; i++) {
  if ((parseInt(aTo[i+1],10) & aIntNetMask[i]) !== aIntNetwork[i]) {
   document.getElementById('spanstatus2').innerHTML="リース範囲終了のアドレスがネットワークに所属していません";
   return;
  }
  lngTo += parseInt(aTo[i+1],10) * Math.pow(256,4-i);
 }
 
 if (lngTo < lngFrom) {
  document.getElementById('spanstatus2').innerHTML="リース範囲で開始と終了が逆転しています";
  return;
 }
 
 //Network/Maskの値を成形
 strNetwork = String(aIntNetwork[0])+'.'+String(aIntNetwork[1])+'.'+String(aIntNetwork[2])+'.'+String(aIntNetwork[3])+"/"+String(aIntNetwork[4]);
 
 //更新チェック
 let i = 0;
 let oTable = document.getElementById('tblnetwork');
 for (let oRow of oTable.rows) {
   if (oRow.cells[0].innerText===strNetwork) {
    oRow.cells[1].innerText=strName;
    oRow.cells[2].innerText=strGateway;
    oRow.cells[3].innerText=strFrom;
    oRow.cells[1].innerText=strTo;
    
    document.getElementById('txtnetwork').value="";
    document.getElementById('txtnname').value="";
    document.getElementById('txtgateway').value="";
    document.getElementById('txtfrom').value="";
    document.getElementById('txtto').value="";
    
    return;
   }
 }
 
 //新規
 let oIRow = oTable.insertRow();
 oIRow.insertCell().appendChild(document.createTextNode(strNetwork));
 oIRow.insertCell().appendChild(document.createTextNode(strName));
 oIRow.insertCell().appendChild(document.createTextNode(strGateway));
 oIRow.insertCell().appendChild(document.createTextNode(strFrom));
 oIRow.insertCell().appendChild(document.createTextNode(strTo));
 
 document.getElementById('txtnetwork').value="";
 document.getElementById('txtnname').value="";
 document.getElementById('txtgateway').value="";
 document.getElementById('txtfrom').value="";
 document.getElementById('txtto').value="";
 
 document.getElementById('spanstatus2').innerHTML="";
}

function postUser() {
 //ユーザー設定反映
 let strParams = "users=";
 let i = 0;
 let oTable = document.getElementById('tbluser');
 for (let oRow of oTable.rows) {
  for(let oCell of oRow.cells){
   if (oCell.tagName==='TD') {
    if (i !== 0) {
     strParams+='\t';
    }
    i++;
    strParams+=oCell.innerText;
   }
  }
 }
 mIntMsgTarget = 1;
 mRequest.open('POST','lease.php',true);
 mRequest.setRequestHeader('content-type', 'application/x-www-form-urlencoded;charset=UTF-8');
 
 mRequest.send(strParams);
}

function postNetwork() {
 //ネットワーク設定反映
 let strParams = "networks=";
 let i = 0;
 let oTable = document.getElementById('tblnetwork');
 for (let oRow of oTable.rows) {
  for(let oCell of oRow.cells){
   if (oCell.tagName==='TD') {
    if (i !== 0) {
     strParams+='\t';
    }
    i++;
    strParams+=oCell.innerText;
   }
  }
 }
 mIntMsgTarget = 2;
 mRequest.open('POST','lease.php',true);
 mRequest.setRequestHeader('content-type', 'application/x-www-form-urlencoded;charset=UTF-8');
 
 mRequest.send(strParams);
}

function postConf() {
 //設定ファイル作成
 let strParams = "conf=1";
 mIntMsgTarget = 2;
 mRequest.open('POST','lease.php',true);
 mRequest.setRequestHeader('content-type', 'application/x-www-form-urlencoded;charset=UTF-8');
 
 mRequest.send(strParams);
}

</script>
<style type="text/css">
	html {font-size:62.5%;}
	body {font-size:1.4rem;}
	h3 {font-size: 1.6rem;}
	table{width:100%; border: 1px solid #ccc; font-size:1.4rem;}
	td, th{border: 1px solid #ccc;}
</style>
</head>
<body>
<h3>DHCPリース情報</h3>
<?php

$aKnownUsers = array();//[mac][name];
$aNetworks = array();//[network][name gateway from to];
$aAccessUsers = array();//[mac][name ip status time];

//ユーザーファイルが存在したら読み込み
if (file_exists(C_USER_LIST) === TRUE) {
	$fp = fopen(C_USER_LIST, 'r');
	if($fp){
		while ($strLine = rtrim(fgets($fp))) {
		 if (substr(trim($strLine),0,1)!=="#") {
		 	$aWk = explode("\t",$strLine);
		 	if (1 < count($aWk)) {
		 		$aKnownUsers[$aWk[0]]=$aWk[1];
		 	}
		 }
		}
	}
	/* ファイルポインタをクローズ */
	fclose($fp);
	
} else {
	$strMsg="htmlﾃﾞｨﾚｸﾄﾘに".C_USER_LIST."を作って書込可にして下さい";
}

//ネットワーク情報があったら読み込み
if (file_exists(C_NETWORK_LIST) === TRUE) {
	$fp = fopen(C_NETWORK_LIST, 'r');
	if($fp){
		while ($strLine = rtrim(fgets($fp))) {
		 if (substr(trim($strLine),0,1)!=="#") {
		 	$aWk = explode("\t",$strLine);
		 	if (4 < count($aWk)) {
		 		$aNetworks[$aWk[0]]=array();
		 		$aNetworks[$aWk[0]]['name']=$aWk[1];
		 		$aNetworks[$aWk[0]]['gateway']=$aWk[2];
		 		$aNetworks[$aWk[0]]['from']=$aWk[3];
		 		$aNetworks[$aWk[0]]['to']=$aWk[4];
		 	}
		 }
		}
	}
	/* ファイルポインタをクローズ */
	fclose($fp);
} else {
	$strMsg="htmlﾃﾞｨﾚｸﾄﾘに".C_NETWORK_LIST."を作って書込可にして下さい";
}

//DHCPログ解析
$strLogPath = getLogPath();
if (file_exists($strLogPath) === TRUE) {
	$fp = fopen($strLogPath, 'r');
	if($fp){
		while ($strLine = rtrim(fgets($fp))) {
		    //日時取得
			$strTime = trim(substr($strLine,0,16));
			if (preg_match('/DHCPACK.*on(.*)\s+to\s+([0-9a-f:]*).*\s+via/',$strLine,$ret)===1) {
			 	//ACK情報
			 	//1:IP 2:MAC
			 	$aAccessUsers[$ret[2]]['time']=$strTime;
			 	$aAccessUsers[$ret[2]]['ip']=$ret[1];
			 	$aAccessUsers[$ret[2]]['name']="未設定";//後から上書きされる
			 	$aAccessUsers[$ret[2]]['status']="許可";
			 	
			} elseif(preg_match('/DHCPDISCOVER.*from\s+([0-9a-f:]*).*\s+via\s+.*unknown client.*/',$strLine,$ret)===1) {
				//拒否情報 deny unknown-client
				//1:MAC
			 	$aAccessUsers[$ret[1]]['time']=$strTime;
			 	$aAccessUsers[$ret[1]]['ip']="";
			 	$aAccessUsers[$ret[1]]['name']="未設定";//後から上書きされる
			 	$aAccessUsers[$ret[1]]['status']="拒否";
			} elseif(preg_match('/DHCPDISCOVER.*from\s+([0-9a-f:]*).*\s+via\s.*network\s+([0-9\.]*).*no free leases.*/',$strLine,$ret)===1) {
				//リースアドレス不足情報
				//1:MAC 2:ネットワーク
			 	$aAccessUsers[$ret[1]]['time']=$strTime;
			 	$aAccessUsers[$ret[1]]['ip']=$ret[2];
			 	$aAccessUsers[$ret[1]]['name']="未設定";//後から上書きされる
			 	$aAccessUsers[$ret[1]]['status']="不足";
			}
		}
	}
	/* ファイルポインタをクローズ */
	fclose($fp);
} else {
 echo "logファイルが存在しません";
}

//設定してあるユーザー名を反映
foreach($aKnownUsers as $key => $value) {
  if (isset($aAccessUsers[$key])) {
  	$aAccessUsers[$key]['name']=$value;
  }
}

echo "<table>";
echo "<tr><th class='mac'>MAC</th><th class='ip'>IP</th><th class='name'>名前</th><th class='status'>Status</th><th class='time'>Last Access</th></tr>";
foreach($aAccessUsers as $key => $value) {
echo "<tr>";
echo "<td class='mac'>".htmlspecialchars($key)."</td>";
echo "<td class='ip'>".htmlspecialchars($value['ip'])."</td>";
echo "<td class='name'>".htmlspecialchars($value['name'])."</td>";
echo "<td class='status'>".htmlspecialchars($value['status'])."</td>";
echo "<td class='time'>".htmlspecialchars($value['time'])."</td>";
echo "</tr>";
}
echo "</table>";
echo "<form name='formpage' method='post'>";
echo "<select name='page'>";
for ($i = 0; $i <= C_LOG_MAX_PAGES; $i++) {
	if (isset($_POST['page'])) {
		$intTarget = (int)$_POST['page'];
	} else {
		$intTarget = 0;
	}
	
	$strSelected ="";
	if ($i === $intTarget) {
		$strSelected =" selected";
	}
	if ($i === 0) {
		echo "<option value='0'".$strSelected.">当日</option>";
	} else {
		echo "<option value='".(string)$i."'".$strSelected.">".(string)$i."日前</option>";
	}
}
echo "</select>";
echo "</form>";
echo '<button onclick="document.formpage.submit();">再表示</button>';
echo "<h3>ユーザー情報</h3>";
echo "<table id='tbluser'>";
echo "<tr><th>MAC</th><th>名前</th></tr>";
foreach($aKnownUsers as $key => $value) {
echo "<tr>";
echo "<td>".htmlspecialchars($key)."</td>";
echo "<td class='name'>".htmlspecialchars($value)."</td>";
echo "</tr>";
}
echo "</table>";
?>
<p>
<table>
<tr>
<td>MAC</td><td><input type="url" id="txtmac" value="" style="width:20em;"></td></tr>
<td>名前</td><td><input type="text" id="txtname" value="" style="width:20em;"></td></tr>
</table>
</p>
<p>
<button onclick="addUser();">リストへ追加</button>
<button onclick="delUser();">入力したMACを削除</button>
<button onclick="postUser();">ユーザー設定を反映</button>
<button onclick="location.reload();">リセット</button>
</p>
<p>
&nbsp;
<span id="spanstatus1">MACアドレスは:で区切って入力してください</span>
</p>

<?php
echo "<h3>ネットワーク情報</h3>";
echo "<table id='tblnetwork'>";
echo "<tr><th>Network/Mask</th><th>Name</th><th>ルーター</th><th>リース範囲開始</th><th>リース範囲終了</th></tr>";

foreach($aNetworks as $key => $value) {
echo "<tr>";
echo "<td>".htmlspecialchars($key)."</td>";
echo "<td class='nname'>".htmlspecialchars($value['name'])."</td>";
echo "<td class='gateway'>".htmlspecialchars($value['gateway'])."</td>";
echo "<td class='from'>".htmlspecialchars($value['from'])."</td>";
echo "<td class='to'>".htmlspecialchars($value['to'])."</td>";
echo "</tr>";
}

echo "</table>";
?>
<p>
<table>
<tr><td>Network/Mask</td><td><input type="url" id="txtnetwork" value="" style="width:20em;"></td></tr>
<tr><td>名前</td><td><input type="text" id="txtnname" value="" style="width:20em;"></td></tr>
<tr><td>ルーター</td><td><input type="url" id="txtgateway" value="" style="width:20em;"></td></tr>
<tr><td>リース範囲開始</td><td><input type="url" id="txtfrom" value="" style="width:20em;"></td></tr>
<tr><td>リース範囲終了</td><td><input type="url" id="txtto" value="" style="width:20em;"></td></tr>
</table>
</p>
<p>
<button onclick="addNetwork();">リストへ追加</button>
<button onclick="delNetwork();">入力したネットワークを削除</button>
<button onclick="postNetwork();">ネットワーク設定を反映</button>
<button onclick="location.reload();">リセット</button>
</p>
<p>
<button onclick="postConf();">dhcpd.conf作成（反映済みの設定が対象）</button>
</p>
<p>
&nbsp;
<span id="spanstatus2">ネットワーク範囲の重複エラーは判定していません(172.16.1.0/24と172.16.0.0/16等)注意してください。</span>
</p>
</body>
</html>

<?php
function convNetworkAddress($strNetwork) {
  // ISC-dhcp-serverのネットワーク記述方式に変換
  
  $intPos = strpos($strNetwork,"/");
  $intNum = 0;
  $strNetworkIp;
  
  if ($intPos === false) {
    return null;
  }
  
  
  $intNum = (int)substr($strNetwork,$intPos+1);
  $strNetworkIp=substr($strNetwork,0,$intPos);
  
  if (8 <= $intNum && $intNum < 32) {
   if ($intNum < 16) {
    return $strNetworkIp." netmask 255.".bindec(str_pad(str_repeat('1',$intNum-8),8,"0")).".0.0";
   } elseif($intNum < 24) {
    return $strNetworkIp." netmask 255.255.".bindec(str_pad(str_repeat('1',$intNum-16),8,"0")).".0";
   } else {
    return $strNetworkIp." netmask 255.255.255.".(string)bindec(str_pad(str_repeat('1',$intNum-24),8,"0"));
   }
  } else {
   //プライベートネットワークで持てる範囲外
   return null;
  }

}

?>