This software is released under the MIT License.

And use MIT Licensed library in lib dir, jquery.qrcode.min.js and jquery-3.4.1.min.js.

See LICENSE.txt.
