<?php
	//アップロードフォルダ指定
	define('UPLOAD_DIR','./uploads');
	$strMsg="";
	$strFiles="";
	$intCnt=0;
	//ファイルの確認
	if(isset($_FILES["uploadfiles"])){
		for ($i=0; $i < count($_FILES["uploadfiles"]["name"]); $i++){
			if(is_uploaded_file($_FILES["uploadfiles"]["tmp_name"][$i])){
				move_uploaded_file($_FILES["uploadfiles"]["tmp_name"][$i], UPLOAD_DIR."/". $_FILES["uploadfiles"]["name"][$i]);
				if ($intCnt != 0) {
					$strFiles.="<br>";
				}
				$strFiles.=$_FILES["uploadfiles"]["name"][$i];
				$intCnt++;
				
			}
		}
	}
	
	if (0 < $intCnt) {
		$strMsg = (string)$intCnt."件アップロードしました<br>".$strFiles ;
	} else {
		$strMsg ="";
	}

?>

<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0">
    <title>ファイルアップローダ</title>
</head>
<body>
    <form aciton="./" method="post" enctype="multipart/form-data">
    	<div>
    	ファイルアップローダ
    	</div>
        <div>
        <input type="file" multiple name="uploadfiles[]" />
        </div>
        <p>&nbsp;</p>
        <div>
        <input type="submit" value="　送　　信　" />
        </div>
        <div>
        <?php echo $strMsg; ?>
        </div>
    </form>
</body>
