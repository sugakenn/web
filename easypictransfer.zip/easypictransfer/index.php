<html>
<head>
<meta charset="utf-8">	
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0">
<title>ファイルアップローダへのリンクページ</title>
<script src="./lib/jquery-3.4.1.min.js"></script>
<script src="./lib/jquery.qrcode.min.js"></script>
</head>
<body>
<h1>アップロードページはこちら</h1>
<div id="qrcodearea"></div>
IPアドレス:<?php echo gethostbyname(php_uname('n')); ?>
<script>
<?php echo('var str="http://'.gethostbyname(php_uname('n')).'/upload.php";'); ?>
jQuery(function($){
$('#qrcodearea').qrcode({width: 128, height: 128, text: str});
})
</script>
</body></html>
