#!/bin/bash
#bind用のブラックリストファイルが存在していたら一旦削除
if [ -e /etc/bind/zones.black ]; then
rm /etc/bind/zones.black
fi
if [ ! -f /var/www/html/blackurls ]; then
#ブラックリストが存在しない場合は終了(ファイルが存在しない場合のエラーを回避するために空のファイルを作成）
echo "#no entry">>/etc/bind/zones.black
echo not found blackurls
exit 1
fi
#行数チェックの変数
counter=0
while read line
do
if [ ${line:0:1} != "#" ]; then
echo 'zone "'${line}'" { type master; file "/etc/bind/db.empty"; };'>>/etc/bind/zones.black
counter=$counter+1
fi
done < /var/www/html/blackurls
if [ $counter = 0 ]; then
#出力対象が存在しない場合にエラーを回避するために空のファイルを作成
echo "#no entry">>/etc/bind/zones.black
fi
#DNSサービスを再起動させて変更を反映させます
systemctl restart bind9
