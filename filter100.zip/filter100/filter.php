<?php

define('C_MANAGE_USER','cat');//管理ユーザーを入力
define('C_MANAGE_PASSWORD','222');//管理パスワードを入力

define('C_BLACK_URLS','blackurls');//閲覧禁止ドメインのリストファイル名
define('C_SCRIPT','/var/www/html/makeblacklist.sh');//BIND設定に反映させるためのスクリプトへのパス

/* punycode.php:日本語(マルチバイト)ドメイン名をDNSで使用可能な文字列に変換するライブラリです */
/* Copyright (c) 2011 Takehito Gondo MIT License */
require_once('punycode.php');

//設定ページに対して簡易的なパスワードをかけています。
//ネットワーク内の通信を監視するとユーザー名とパスワードが見らてしまいます。
$blnSuperUser = false;
if (isset($_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW'])) {
	if ($_SERVER['PHP_AUTH_USER'] === C_MANAGE_USER) {
		if ($_SERVER['PHP_AUTH_PW'] === C_MANAGE_PASSWORD) {
			$blnSuperUser = true;
		}
	}
}
if ($blnSuperUser === false) {
	header('WWW-Authenticate: Basic realm="Enter username and password."');
	header('Content-Type: text/plain; charset=utf-8');
	die('管理者ログインが必要です');
}

//もし設定変更が送信されてきたら書き込み
$strMsg="";
if (isset($_POST['domains'])) {
	$domain = explode("\t",$_POST['domains']);
	$fp = fopen(C_BLACK_URLS, 'w');
	if ($fp) {
		for ($i = 0; $i < count($domain); $i++) {
			fputs($fp,convjpdomain($domain[$i])."\n");
		}
		
		//設定変更スクリプト実行
		$output = shell_exec("sudo ".C_SCRIPT);
		
		$strMsg="書き込みました(".$output.")";
	} else {
		$strMsg="書き込みに失敗しました";
	}
	fclose($fp);
}
?>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0">
    <title>閲覧禁止ドメイン設定</title>
	<!-- ブラウザ上でリストボックスを編集するためのJavaスクリプト -->
	<script>
		const delrow = () => {
			const listbox = document.formburl.listbox;
			for (let i = listbox.length-1; 0 <= i ;i--) {
				if (typeof(listbox[i])!=="undefined") {
					if (listbox[i].selected){
						listbox.removeChild(listbox[i]);
					}
				}
			}
		}
		
		const selectmode = () => {
			const radios = document.getElementsByName('mode');

			for (let i = 0; i < radios.length;i++) {
				if (radios[i].checked){
					switch(radios[i].value) {
					case "0":
						addcomment();
						break;
					case "1":
						if (checkurl()==0) {
							addurl();
						} else {
							alert("ドメイン名が不正です");
						}
						break;
					case "2":
						addurl();//日本語ドメインはノーチェックで追加
						break;
					default:
					}
					
					return;
				}
			}
		}
		
		const addurl = () => {
			//URLをリストに追加
			const listbox = document.formburl.listbox;
			const strurl=document.getElementById('txt').value;
			let optionU = document.createElement('option');
			
			//空白の時は何もしない
			if (strurl === "") {
				return;
			}
			
			optionU.value=strurl;
			if (typeof(optionU.innerText) != 'undefined') {
				optionU.innerText = strurl;
			} else {
				optionU.text = strurl;
			}
			
			listbox.appendChild(optionU);
			
			document.getElementById('txt').value="";
		}
		
		const addcomment = () => {
			//コメントをリストに追加(空白許可)
			
			const listbox = document.formburl.listbox;
			const strcomment=document.getElementById('txt').value;
			
			let optionC = document.createElement('option');
			
			optionC.value="#"+strcomment;
			if (typeof(optionC.innerText) != 'undefined') {
				optionC.innerText = "#"+strcomment;
			} else {
				optionC.text = "#"+strcomment;
			}
			
			listbox.appendChild(optionC);
			document.getElementById('txt').value="";
			listbox.size=20;
		}
		
		const checkurl = () => {
			let strurl=document.getElementById('txt').value;
			let data = strurl.match(/([A-Za-z0-9][A-Za-z0-9\-]{1,61}[A-Za-z0-9]\.)+[A-Za-z]+/);
			if (!data) {
				return 1;
			}
			
			return 0;
		}
		
		const postvalue = () => {
			//設定変更を送信
			const listbox = document.formburl.listbox;
			let rawdata = "";
			let form = document.createElement('form');
			let inp = document.createElement('input');
			
			for (let i = 0; i < listbox.length; i++) {
				if (i != 0) {
					rawdata += "\t";
				}
				if (typeof(listbox[i])!=="undefined") {
					rawdata += listbox[i].value;
				}
			}
			
			form.method = 'POST';
			form.action = '';
			inp.type = 'hidden';
			inp.name = 'domains';
			inp.value = rawdata;
			
			form.appendChild(inp);
			document.body.appendChild(form);
			form.submit();
		}
	</script>
</head>
<body>
<h3>閲覧禁止ドメイン設定</h3>
<form name="formburl">
<select name="listbox" multiple="" style="width:30em; height:20em;">
<?php
//ファイルが存在したら読み込み、そうでなければ空のファイルを作成
if (file_exists(C_BLACK_URLS) === TRUE) {
	$fp = fopen(C_BLACK_URLS, 'r');
	if($fp){
		while ($strLine = fgets($fp)) {
			$strWk = reversejpdomain(str_replace("\n","",$strLine));
			echo'<option value="'.$strWk.'">'.$strWk.'</option>';
		}
	}
	/* ファイルポインタをクローズ */
	fclose($fp);
} else {
	$strMsg="htmlﾃﾞｨﾚｸﾄﾘに".C_BLACK_URLS."を作って書込可にして下さい";
}
?>
</select>
</form>
<p>登録のモード<br>
<input type="radio" name="mode" value="0">コメント
<input type="radio" name="mode" value="1" checked>ドメイン
<input type="radio" name="mode" value="2" >日本語ドメイン
</p>
<p>
<input type="text" id="txt" value="" style="width:20em;">
</p>
<p>
<button onclick="selectmode();">リストへ追加</button>
<button onclick="delrow();">選択行を削除</button>
<button onclick="postvalue();">設定を反映</button>
<button onclick="location.reload();">リセット</button>
</p>
<p>
&nbsp;
<?php
	echo $strMsg;
?>
</p>
</body>
</html>
<?php
//日本語ドメインメイン名DNSサーバが理解できる文字に変換します。
function convjpdomain($str) {
	$ret="";
	//コメントの時は無視
	if (substr($str,0,1)==="#") {
		return $str;
	} else {
		$domain = explode(".",$str);
		for($i=0;$i<count($domain);$i++){
			if ($i !=0) {
				$ret .=".";
			}
			if (isjp($domain[$i]) == 0) {
				//Punycode変換
				$ret .= Punycode::encode($domain[$i]);
			} else {
				$ret .= $domain[$i];//そのまま付与
			}
		}
		return $ret;
	}
}
//変換したデータから日本語ドメインに戻す
function reversejpdomain($str) {
	$ret="";
	//コメントの時は無視
	if (substr($str,0,1)==="#") {
		return $str;
	} else {
		$domain = explode(".",$str);
		
		for($i=0;$i<count($domain);$i++){
			if ($i !=0) {
				$ret .=".";
			}
			if (substr($domain[$i],0,4) === "xn--") {
				//Punycode復元
				$ret .= Punycode::decode($domain[$i]);
			} else {
				$ret .= $domain[$i];//そのまま付与
			}
		}
		return $ret;
	}
}
function isjp($str) {

	if ($str==="") {
		//空白は非マルチバイト文字扱い
		return 1;
	}
	
	//非マルチバイト文字で1が返り、マルチバイト文字で0が返る
	return preg_match("/[A-Za-z0-9][A-Za-z0-9\-]{1,61}[A-Za-z0-9]/",$str);
}
?>

